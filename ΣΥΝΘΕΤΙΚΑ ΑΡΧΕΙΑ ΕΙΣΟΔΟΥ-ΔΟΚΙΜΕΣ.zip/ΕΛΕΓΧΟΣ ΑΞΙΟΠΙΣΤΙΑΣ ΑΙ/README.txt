Με έλεγχο συνδέσμου
https://www.icsd.aegean.gr/