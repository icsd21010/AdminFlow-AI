import locale
import os
import sys
from pathlib import Path

from flask import Flask, app, render_template, session, redirect, url_for, request

from config import (
    MAX_CONTENT_LENGTH,
    MINUTES_UPLOAD_FOLDER,
    MINUTES_TRANSCRIPT_UPLOAD_FOLDER,
    DOCUMENT_EDITING_UPLOAD_FOLDER,
    CERTIFICATE_TEACHING_UPLOAD_FOLDER,
    TEXT_VERIFICATION_UPLOAD_FOLDER,
    PRESS_RELEASE_UPLOAD_FOLDER,
    TRANSLATION_UPLOAD_FOLDER,
    CHECK_HOUSING_MEALS_UPLOAD_FOLDER,
    CHECK_GRADUATION_REQUIREMENTS_UPLOAD_FOLDER,
    TRANSFER_SUSPENSION_UPLOAD_FOLDER,
    TUITION_SCHOLARSHIP_UPLOAD_FOLDER,
    ELECTION_COMMITTEE_UPLOAD_FOLDER,
    TROUBLESHOOTING_UPLOAD_FOLDER,
    CATEGORIZATION_EXPENDITURE_UPLOAD_FOLDER,
    PROTOCOL_REPORT_UPLOAD_FOLDER,
    FACULTY_EXPERIENCE_UPLOAD_FOLDER,
    EDUCATIONAL_LEAVES_UPLOAD_FOLDER,
    DAYK_UPLOAD_FOLDER, 
    TRAVEL_EXPENSES_UPLOAD_FOLDER,
    OUTPUT_FOLDER,
    STATIC_FOLDER,
    TEMPLATES_FOLDER,
    UPLOAD_FOLDER,
    TRANSLATIONS,
    ensure_project_directories,
)
from logging_setup import setup_logging
from modules.minutes.routes import bp as minutes_bp
from modules.press_release.routes import bp as press_release_bp
from modules.translation.routes import bp as translation_bp
from modules.minutes_transcript.routes import bp as minutes_transcript_bp
from modules.document_editing.routes import bp as document_editing_bp
from modules.certificate_teaching.routes import bp as certificate_teaching_bp
from modules.text_verification.routes import bp as text_verification_bp
from modules.check_housing_meals.routes import bp as check_housing_meals_bp
from modules.check_graduation_requirements.routes import bp as check_graduation_requirements_bp
from modules.transfer_suspension.routes import bp as transfer_suspension_bp
from modules.tuition_scholarship.routes import bp as tuition_scholarship_bp
from modules.election_committee.routes import bp as election_committee_bp
from modules.troubleshooting_llm.routes import bp as troubleshooting_llm_bp
from modules.categorization_expenditure.routes import bp as categorization_expenditure_bp
from modules.protocol_report.routes import bp as protocol_report_bp
from modules.faculty_experience.routes import bp as faculty_experience_bp
from modules.educational_leaves.routes import bp as educational_leaves_bp
from modules.dayk.routes import bp as dayk_bp
from modules.travel_expenses.routes import bp as travel_expenses_bp

os.environ["PYTHONIOENCODING"] = "utf-8"

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

try:
    locale.setlocale(locale.LC_ALL, "en_US.UTF-8")
except locale.Error:
    pass

for stream_name in ("stdout", "stderr"):
    stream = getattr(sys, stream_name, None)

    if stream and hasattr(stream, "reconfigure"):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


PROJECT_ROOT = Path(__file__).resolve().parent
logger = setup_logging(PROJECT_ROOT)
# =====================================================================
# EPHEMERAL FILES & GARBAGE COLLECTOR
# =====================================================================
import time
import atexit
from apscheduler.schedulers.background import BackgroundScheduler

def garbage_collector_job():
    """Διαγράφει ξεχασμένα αρχεία σε uploads/outputs παλαιότερα των 3 λεπτών."""
    folders_to_clean = [
        os.path.join(PROJECT_ROOT, 'uploads'),
        os.path.join(PROJECT_ROOT, 'outputs')
    ]
    max_age_seconds = 3 * 60 # 3 λεπτά

    for folder in folders_to_clean:
        if not os.path.exists(folder):
            continue
        for root, dirs, files in os.walk(folder):
            for file in files:
                if file == '.gitkeep': # Κρατάμε τα κρυφά αρχεία δομής
                    continue
                file_path = os.path.join(root, file)
                try:
                    # Αν είναι παλιότερο από 3 λεπτά, διέγραψέ το
                    if os.stat(file_path).st_mtime < time.time() - max_age_seconds:
                        os.remove(file_path)
                        logger.info(f"Garbage Collector: Καθαρίστηκε παλιό αρχείο: {file_path}")
                except Exception:
                    pass

# Εκκίνηση του Scheduler στο background
scheduler = BackgroundScheduler()
scheduler.add_job(func=garbage_collector_job, trigger="interval", minutes=3)
scheduler.start()
atexit.register(lambda: scheduler.shutdown())
# =====================================================================

PROCESS_CATALOG = [
    {
        "slug": "faculty-experience",
        "title": "fac_exp_title",
        "description": "fac_exp_desc",
        "icon": "🏛️",
        "status_class": "active",
        "category": "faculty",
        "endpoint": "faculty_experience.faculty_experience",
    },
    {
        "slug": "educational-leaves", 
        "title": "el_title",
        "description": "el_desc",
        "icon": "📅",
        "status_class": "active",
        "category": "faculty",
        "endpoint": "educational_leaves.educational_leaves",
    },
    {
        "slug": "dayk",
        "title": "dayk_title",
        "description": "dayk_desc",
        "icon": "🗂️",
        "status_class": "active",
        "category": "faculty",
        "endpoint": "dayk.dayk",
    },
    {
        "slug": "travel-expenses",
        "title": "te_title",
        "description": "te_desc",
        "icon": "✈️",
        "status_class": "active",
        "category": "finance",
        "endpoint": "travel_expenses.travel_expenses",
    },
    {
        "slug": "protocol-report",
        "title": "protocol_report_title",
        "description": "protocol_report_desc",
        "icon": "📊",
        "status_class": "active",
        "category": "documents",
        "endpoint": "protocol_report.protocol_report",
    },
    {
        "slug": "categorization-expenditure",
        "title": "cat_exp_title",
        "description": "cat_exp_desc",
        "icon": "🧾",
        "status_class": "active",
        "category": "finance",
        "endpoint": "categorization_expenditure.categorization_expenditure",
    },
    {
        "slug": "election-committee",
        "title": "ec_title",
        "description": "ec_desc",
        "icon": "⚖️",
        "status_class": "active",
        "category": "faculty",
        "endpoint": "election_committee.election_committee",
    },
    {
        "slug": "check-housing-meals",
        "title": "hm_title",
        "description": "hm_desc",
        "icon": "🏠",
        "status_class": "active",
        "category": "students",
        "endpoint": "check_housing_meals.check_housing_meals",
    },
    {
        "slug": "check-graduation-requirements",
        "title": "grad_title",
        "description": "grad_desc",
        "icon": "🎓",
        "status_class": "active",
        "category": "students",
        "endpoint": "check_graduation_requirements.check_graduation_requirements",
    },
    {
        "slug": "tuition-scholarship",
        "title": "tuit_title",
        "description": "tuit_desc",
        "icon": "💰",
        "status_class": "active",
        "category": "students",
        "endpoint": "tuition_scholarship.tuition_scholarship",
    },
    {
        "slug": "transfer-suspension",
        "title": "ts_title",
        "description": "ts_desc",
        "icon": "🔄",
        "status_class": "active",
        "category": "students",
        "endpoint": "transfer_suspension.transfer_suspension",
    },
    {
        "slug": "press-release",
        "title": "pr_title",
        "description": "pr_desc",
        "icon": "📰",
        "status_class": "active",
        "category": "documents",
        "endpoint": "press_release.press_release",
    },
    {
        "slug": "translation",
        "title": "trans_title",
        "description": "trans_desc",
        "icon": "🌐",
        "status_class": "active",
        "category": "documents",
        "endpoint": "translation.translation",
    },
    {
        "slug": "minutes",
        "title": "min_title",
        "description": "min_desc",
        "icon": "🎙️",
        "status_class": "active",
        "category": "documents",
        "endpoint": "minutes.minutes",
    },
    {
        "slug": "minutes-transcript",
        "title": "mintrans_title",
        "description": "mintrans_desc",
        "icon": "📝",
        "status_class": "active",
        "category": "documents",
        "endpoint": "minutes_transcript.minutes_transcript",
    },
    {
        "slug": "document-editing",
        "title": "doc_title",
        "description": "doc_desc",
        "icon": "✍️",
        "status_class": "active",
        "category": "documents",
        "endpoint": "document_editing.document_editing",
    },
    {
        "slug": "certificate-teaching",
        "title": "cert_title",
        "description": "cert_desc",
        "icon": "📜",
        "status_class": "active",
        "category": "faculty",
        "endpoint": "certificate_teaching.certificate_teaching",
    },
    {
        "slug": "text-verification",
        "title": "textver_title",
        "description": "textver_desc",
        "icon": "🛡️",
        "status_class": "active",
        "category": "documents",
        "endpoint": "text_verification.text_verification",
    },
]


def create_app():
    ensure_project_directories()
    logger.info("Application startup | project_root=%s", PROJECT_ROOT)

    app = Flask(
        __name__,
        template_folder=str(TEMPLATES_FOLDER),
        static_folder=str(STATIC_FOLDER),
    )
    
    app.secret_key = "adminflow_ai_secret_key_change_me"

    app.config["UPLOAD_FOLDER"] = str(UPLOAD_FOLDER)
    app.config["MINUTES_UPLOAD_FOLDER"] = str(MINUTES_UPLOAD_FOLDER)
    app.config["MINUTES_TRANSCRIPT_UPLOAD_FOLDER"] = str(MINUTES_TRANSCRIPT_UPLOAD_FOLDER)
    app.config["DOCUMENT_EDITING_UPLOAD_FOLDER"] = str(DOCUMENT_EDITING_UPLOAD_FOLDER)
    app.config["CERTIFICATE_TEACHING_UPLOAD_FOLDER"] = str(CERTIFICATE_TEACHING_UPLOAD_FOLDER)
    app.config["TEXT_VERIFICATION_UPLOAD_FOLDER"] = str(TEXT_VERIFICATION_UPLOAD_FOLDER)
    app.config["PRESS_RELEASE_UPLOAD_FOLDER"] = str(PRESS_RELEASE_UPLOAD_FOLDER)
    app.config["TRANSLATION_UPLOAD_FOLDER"] = str(TRANSLATION_UPLOAD_FOLDER)
    app.config["CHECK_HOUSING_MEALS_UPLOAD_FOLDER"] = str(CHECK_HOUSING_MEALS_UPLOAD_FOLDER)
    app.config["CHECK_GRADUATION_REQUIREMENTS_UPLOAD_FOLDER"] = str(CHECK_GRADUATION_REQUIREMENTS_UPLOAD_FOLDER)
    app.config["TRANSFER_SUSPENSION_UPLOAD_FOLDER"] = str(TRANSFER_SUSPENSION_UPLOAD_FOLDER)
    app.config["TUITION_SCHOLARSHIP_UPLOAD_FOLDER"] = str(TUITION_SCHOLARSHIP_UPLOAD_FOLDER)
    app.config["ELECTION_COMMITTEE_UPLOAD_FOLDER"] = str(ELECTION_COMMITTEE_UPLOAD_FOLDER)
    app.config["TROUBLESHOOTING_UPLOAD_FOLDER"] = str(TROUBLESHOOTING_UPLOAD_FOLDER)
    app.config["CATEGORIZATION_EXPENDITURE_UPLOAD_FOLDER"] = str(CATEGORIZATION_EXPENDITURE_UPLOAD_FOLDER)
    app.config["PROTOCOL_REPORT_UPLOAD_FOLDER"] = str(PROTOCOL_REPORT_UPLOAD_FOLDER)
    app.config["FACULTY_EXPERIENCE_UPLOAD_FOLDER"] = str(FACULTY_EXPERIENCE_UPLOAD_FOLDER)
    app.config["EDUCATIONAL_LEAVES_UPLOAD_FOLDER"] = str(EDUCATIONAL_LEAVES_UPLOAD_FOLDER)
    app.config["DAYK_UPLOAD_FOLDER"] = str(DAYK_UPLOAD_FOLDER)
    app.config["TRAVEL_EXPENSES_UPLOAD_FOLDER"] = str(TRAVEL_EXPENSES_UPLOAD_FOLDER)
    app.config["OUTPUT_FOLDER"] = str(OUTPUT_FOLDER)
    app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH

    app.register_blueprint(press_release_bp, url_prefix="/press-release")
    app.register_blueprint(translation_bp, url_prefix="/translation")
    app.register_blueprint(minutes_bp, url_prefix="/minutes")
    app.register_blueprint(minutes_transcript_bp, url_prefix="/minutes-transcript")
    app.register_blueprint(document_editing_bp, url_prefix="/document-editing")
    app.register_blueprint(certificate_teaching_bp, url_prefix="/certificate-teaching")
    app.register_blueprint(text_verification_bp, url_prefix="/text-verification")
    app.register_blueprint(check_housing_meals_bp, url_prefix="/check-housing-meals")
    app.register_blueprint(check_graduation_requirements_bp, url_prefix="/check-graduation-requirements")
    app.register_blueprint(transfer_suspension_bp, url_prefix="/transfer-suspension")
    app.register_blueprint(tuition_scholarship_bp, url_prefix="/tuition-scholarship")
    app.register_blueprint(election_committee_bp, url_prefix="/election-committee")
    app.register_blueprint(troubleshooting_llm_bp, url_prefix="/troubleshooting_llm")
    app.register_blueprint(categorization_expenditure_bp, url_prefix="/categorization-expenditure")
    app.register_blueprint(protocol_report_bp, url_prefix="/protocol-report")
    app.register_blueprint(faculty_experience_bp, url_prefix="/faculty-experience")
    app.register_blueprint(educational_leaves_bp, url_prefix="/educational-leaves") 
    app.register_blueprint(dayk_bp, url_prefix="/dayk")
    app.register_blueprint(travel_expenses_bp, url_prefix="/travel-expenses")

    @app.context_processor
    def inject_language_and_translations():
        lang = session.get("lang", "el")
        def translate(key):
            return TRANSLATIONS.get(lang, TRANSLATIONS["en"]).get(key, key)
        return dict(current_lang=lang, t=translate)

    @app.route("/set-language/<lang_code>")
    def set_language(lang_code):
        if lang_code in ["el", "en"]:
            session["lang"] = lang_code
        return redirect(request.referrer or url_for("home"))

    @app.route("/")
    def home():
        logger.info("Home page request")
        return render_template("home.html", processes=PROCESS_CATALOG)

    @app.route("/helpdesk")
    def helpdesk():
        logger.info("Helpdesk page request")
        return render_template("troubleshooting.html")

    @app.route("/processes/<process_slug>")
    def process_placeholder(process_slug):
        selected_process = next(
            (
                process
                for process in PROCESS_CATALOG
                if process["slug"] == process_slug
            ),
            None,
        )

        if selected_process is None:
            logger.warning(
                "Workflow not found | process_slug=%s",
                process_slug,
            )
            return "Workflow not found.", 404

        logger.info(
            "Process placeholder view | process_slug=%s",
            process_slug,
        )
        return render_template(
            "process_placeholder.html",
            process=selected_process,
        )

    @app.errorhandler(413)
    def request_entity_too_large(error):
        logger.warning(
            "Upload rejected due to size | max_bytes=%s",
            MAX_CONTENT_LENGTH,
        )
        return render_template(
            "minutes_form.html",
            error_message=(
                "The total file size exceeds the allowed limit "
                "of 16 MB."
            ),
        ), 413

    @app.errorhandler(500)
    def internal_server_error(error):
        logger.exception("Unexpected application error")
        return render_template(
            "minutes_form.html",
            error_message=(
                "An unexpected technical problem occurred. "
                "Please try again later."
            ),
        ), 500

    return app


app = create_app()

@app.after_request
def add_security_headers(response):
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    return response

if __name__ == "__main__":
    logger.info("Development server startup | debug=True")
    app.run(debug=True)