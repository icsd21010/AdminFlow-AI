import os
import logging

logger = logging.getLogger("ai_process_accelerator")

def cleanup_files(file_paths):
    """Άμεση διαγραφή των αρχείων εισόδου μόλις τελειώσει η διεργασία."""
    for file_path in file_paths:
        try:
            if file_path and os.path.exists(file_path):
                os.remove(file_path)
                logger.info(f"Το εφήμερο αρχείο διαγράφηκε επιτυχώς: {file_path}")
        except Exception as e:
            logger.error(f"Αποτυχία διαγραφής εφήμερου αρχείου {file_path}: {e}")