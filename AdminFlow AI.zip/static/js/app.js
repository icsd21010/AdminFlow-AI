document.addEventListener("DOMContentLoaded", () => {
    // --- WORKFLOW FILTER PILLS LOGIC ---
    const filterPills = document.querySelectorAll(".filter-pill");
    const processCards = document.querySelectorAll(".process-card");

    if (filterPills.length > 0 && processCards.length > 0) {
        filterPills.forEach(pill => {
            pill.addEventListener("click", () => {
                filterPills.forEach(p => p.classList.remove("active"));
                pill.classList.add("active");

                const selectedFilter = pill.getAttribute("data-filter");

                processCards.forEach(card => {
                    const cardCategory = card.getAttribute("data-category");
                    if (selectedFilter === "all" || cardCategory === selectedFilter) {
                        card.classList.remove("is-hidden");
                    } else {
                        card.classList.add("is-hidden");
                    }
                });
            });
        });
    }

    // --- DYNAMIC HELPDESK CHIPS (PURE DOM FILTERING) ---
    const categorySelect = document.getElementById("support_category");
    const quickChipsContainer = document.getElementById("quick-chips");
    const quickChips = document.querySelectorAll(".quick-chip");
    const queryInput = document.getElementById("user_query");

    if (categorySelect && quickChipsContainer && quickChips.length > 0) {
        quickChips.forEach(chip => {
            chip.addEventListener("click", () => {
                const promptText = chip.getAttribute("data-prompt");
                if (queryInput && promptText) {
                    queryInput.value = promptText;
                    queryInput.focus();
                }
            });
        });

        categorySelect.addEventListener("change", () => {
            const selectedCat = categorySelect.value;
            let visibleCount = 0;

            quickChips.forEach(chip => {
                if (chip.getAttribute("data-category") === selectedCat) {
                    chip.style.display = "inline-flex";
                    visibleCount++;
                } else {
                    chip.style.display = "none";
                }
            });

            if (visibleCount > 0) {
                quickChipsContainer.style.display = "block";
            } else {
                quickChipsContainer.style.display = "none";
            }
        });
    }

    // --- TRANSLATION HELPER FOR JAVASCRIPT ---
    const langAttr = document.documentElement.lang || 'el';
    const currentLang = langAttr.toLowerCase().startsWith('en') ? 'en' : 'el';
    
    const trans = {
        'no_file': { el: 'Δεν έχει επιλεγεί αρχείο.', en: 'No file selected.' },
        'processing': { el: 'Επεξεργασία αιτήματος...', en: 'Processing request...' },
        'select_category': { el: 'Παρακαλώ επιλέξτε κατηγορία πρώτα!', en: 'Please select a category first!' },
        'enter_query': { el: 'Πληκτρολογήστε ερώτημα ή ανεβάστε αρχείο!', en: 'Please enter a query or upload a file!' },
        'copied': { el: '✓ Αντιγράφηκε', en: '✓ Copied' },
        'edit_q': { el: 'Επεξεργασία ερώτησης', en: 'Edit question' },
        'you': { el: 'Εσείς', en: 'You' },
        'files_attached': { el: 'αρχείο(α) επισυνάφθηκαν', en: 'file(s) attached' },
        'thinking': { el: 'Σκέφτεται...', en: 'Thinking...' },
        'copy': { el: '📋 Αντιγραφή', en: '📋 Copy' },
        'error': { el: 'Σφάλμα', en: 'Error' },
        'net_error': { el: 'Σφάλμα Δικτύου', en: 'Network Error' },
        'net_error_desc': { el: 'Αποτυχία επικοινωνίας με τον διακομιστή. Ελέγξτε τη σύνδεσή σας.', en: 'Failed to communicate with the server. Check your connection.' },
        'el_select_leave_ph': { el: 'Επιλέξτε τύπο άδειας...', en: 'Select leave type...' }
    };
    
    function t(key) {
        return trans[key] ? (trans[key][currentLang] || trans[key]['el']) : key;
    }

    // --- 1. EXISTING LOGIC FOR STANDARD FORMS ---
    const fileInput = document.querySelector("#files");
    const fileList = document.querySelector("#file-list");
    const forms = document.querySelectorAll("form.card");

    if (fileInput && fileList) {
        fileInput.addEventListener("change", () => {
            fileList.innerHTML = "";
            if (fileInput.files.length === 0) {
                const item = document.createElement("li");
                item.textContent = t('no_file');
                fileList.appendChild(item);
                return;
            }
            for (const file of fileInput.files) {
                const item = document.createElement("li");
                const sizeInMb = (file.size / 1024 / 1024).toFixed(2);
                item.innerHTML = `<strong>${file.name}</strong> <span style="opacity:0.7">(${sizeInMb} MB)</span>`;
                fileList.appendChild(item);
            }
        });
    }

    forms.forEach(form => {
        if (form.id === "troubleshooting-chat-form") return;
        form.addEventListener("submit", () => {
            const submitButton = form.querySelector("button[type='submit']");
            if (submitButton) {
                setTimeout(() => {
                    submitButton.disabled = true;
                    submitButton.innerHTML = `<span class="spinner"></span> ${t('processing')}`;
                }, 10);
            }
        });
    });

    // --- 2. AJAX CHAT LOGIC WITH COPY & EDIT ---
    const chatForm = document.getElementById("troubleshooting-chat-form");
    const chatMessages = document.getElementById("chat-messages");
    
    if (chatForm && chatMessages) {
        const categorySelectChat = document.getElementById("support_category");
        const chatInputWrapper = document.getElementById("chat-input-wrapper");
        const categoryWrapper = document.getElementById("category-wrapper");
        const chatFileInput = document.getElementById("chat_files");
        const chatFileDisplay = document.getElementById("chat-file-display");
        const queryInputChat = document.getElementById("user_query");

        if (categorySelectChat && chatInputWrapper) {
            categorySelectChat.addEventListener("change", () => {
                if (categorySelectChat.value !== "") {
                    chatInputWrapper.classList.remove("locked");
                } else {
                    chatInputWrapper.classList.add("locked");
                }
            });
        }

        if (chatFileInput && chatFileDisplay) {
            chatFileInput.addEventListener("change", () => {
                if (chatFileInput.files.length > 0) {
                    const extra = chatFileInput.files.length > 1 ? ` (+${chatFileInput.files.length - 1})` : "";
                    chatFileDisplay.innerHTML = `📎 ${chatFileInput.files[0].name}${extra}`;
                } else {
                    chatFileDisplay.innerHTML = "";
                }
            });
        }

        function showErrorCloud(element, message) {
            let existingCloud = element.querySelector('.error-cloud');
            if (existingCloud) existingCloud.remove();

            const cloud = document.createElement('div');
            cloud.className = 'error-cloud';
            cloud.textContent = message;
            element.appendChild(cloud);

            void cloud.offsetWidth;
            cloud.classList.add('show');

            setTimeout(() => {
                cloud.classList.remove('show');
                setTimeout(() => cloud.remove(), 300);
            }, 3000);
        }

        window.copyChatText = function(btn) {
            const messageNode = btn.closest('.chat-message').querySelector('.message-content');
            const content = messageNode ? messageNode.innerText : "";

            if (!content) return;

            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(content).then(() => {
                    showCopiedFeedback(btn);
                }).catch(() => {
                    fallbackCopyChat(content, btn);
                });
            } else {
                fallbackCopyChat(content, btn);
            }

            function showCopiedFeedback(buttonElement) {
                const originalText = buttonElement.innerHTML;
                buttonElement.innerHTML = t('copied');
                setTimeout(() => { buttonElement.innerHTML = originalText; }, 2000);
            }

            function fallbackCopyChat(text, buttonElement) {
                const tempTextArea = document.createElement("textarea");
                tempTextArea.value = text;
                tempTextArea.style.position = "fixed";
                tempTextArea.style.top = "0";
                tempTextArea.style.left = "0";
                tempTextArea.style.opacity = "0";
                document.body.appendChild(tempTextArea);
                tempTextArea.focus();
                tempTextArea.select();
                try {
                    const successful = document.execCommand('copy');
                    if (successful) {
                        showCopiedFeedback(buttonElement);
                    } else {
                        alert(currentLang === 'en' ? "Copy failed. Please use Ctrl+C." : "Αποτυχία αντιγραφής. Χρησιμοποιήστε Ctrl+C.");
                    }
                } catch (err) {
                    alert(currentLang === 'en' ? "Browser does not support auto-copy." : "Το πρόγραμμα περιήγησης δεν υποστηρίζει αυτόματη αντιγραφή.");
                }
                document.body.removeChild(tempTextArea);
                if (window.getSelection) {
                    window.getSelection().removeAllRanges();
                }
            }
        };

        window.editUserPrompt = function(btn) {
            const userMsgBlock = btn.closest('.chat-message');
            const turnId = userMsgBlock.dataset.turnId;
            const textElement = userMsgBlock.querySelector('.user-query-text');
            const originalPrompt = textElement ? textElement.innerText : "";

            if (queryInputChat) {
                queryInputChat.value = originalPrompt;
                queryInputChat.focus();
            }

            userMsgBlock.remove();
            const correspondingAi = document.querySelector(`.ai-message[data-turn-id="${turnId}"]`);
            if (correspondingAi) correspondingAi.remove();
        };

        chatForm.addEventListener("submit", async (e) => {
            e.preventDefault(); 
            
            if (categorySelectChat.value === "") {
                showErrorCloud(categoryWrapper, t('select_category'));
                return;
            }

            const submitButton = chatForm.querySelector("button[type='submit']");
            const queryText = queryInputChat ? queryInputChat.value.trim() : "";
            const categoryText = categorySelectChat.options[categorySelectChat.selectedIndex].text;
            const files = chatFileInput ? chatFileInput.files : [];

            if (queryText === "" && files.length === 0) {
                showErrorCloud(chatInputWrapper, t('enter_query'));
                return;
            }
            
            const turnId = 'turn-' + Date.now();

            let userMessageHtml = `
                <div class="chat-message user-message" data-turn-id="${turnId}">
                    <div class="message-meta">
                        <button type="button" onclick="editUserPrompt(this)" class="chat-icon-btn" title="${t('edit_q')}">✏️</button>
                        <strong>${t('you')}</strong> (${categoryText})
                    </div>
                    <div class="message-content">
            `;
            if (queryText) userMessageHtml += `<p class="user-query-text" style="margin:0;">${queryText}</p>`;
            if (files.length > 0) {
                userMessageHtml += `<p class="chat-attachment" style="margin:5px 0 0 0; font-size:0.9em; opacity:0.8;">📎 ${files.length} ${t('files_attached')}</p>`;
            }
            userMessageHtml += `</div></div>`;
            chatMessages.insertAdjacentHTML('beforeend', userMessageHtml);
            chatMessages.scrollTop = chatMessages.scrollHeight;
            
            if (submitButton) {
                submitButton.dataset.originalText = submitButton.innerHTML; 
                submitButton.disabled = true;
                submitButton.innerHTML = `<span class="spinner" style="width:1rem; height:1rem;"></span>`;
            }
            chatInputWrapper.classList.add("locked");
            
            const loadingId = 'loading-' + Date.now();
            const loadingHtml = `
                <div id="${loadingId}" class="chat-message ai-message loading-message">
                    <div class="message-meta"><strong>AdminFlow AI</strong></div>
                    <div class="message-content"><span class="spinner" style="width:1rem;height:1rem;vertical-align:middle;margin-right:8px; border-top-color: var(--primary);"></span> <em>${t('thinking')}</em></div>
                </div>`;
            chatMessages.insertAdjacentHTML('beforeend', loadingHtml);
            chatMessages.scrollTop = chatMessages.scrollHeight;

            const formData = new FormData(chatForm);

            try {
                const response = await fetch('/troubleshooting_llm/', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                const loadingNode = document.getElementById(loadingId);
                if (loadingNode) loadingNode.remove();
                
                if (data.success) {
                    const formattedText = data.response.replace(/\n/g, '<br>');
                    let aiHtml = `
                        <div class="chat-message ai-message" data-turn-id="${turnId}">
                            <div class="message-meta"><strong>AdminFlow AI</strong></div>
                            <div class="message-content">${formattedText}</div>
                            <div class="chat-actions" style="margin-top: 6px;">
                                <button type="button" onclick="copyChatText(this)" class="chat-action-btn">${t('copy')}</button>
                            </div>
                        </div>`;
                    chatMessages.insertAdjacentHTML('beforeend', aiHtml);
                } else {
                    chatMessages.insertAdjacentHTML('beforeend', `
                        <div class="chat-message error-message">
                            <div class="message-meta"><strong>${t('error')}</strong></div>
                            <div class="message-content">${data.error_message}</div>
                        </div>`);
                }
            } catch (error) {
                const loadingNode = document.getElementById(loadingId);
                if (loadingNode) loadingNode.remove();
                
                chatMessages.insertAdjacentHTML('beforeend', `
                    <div class="chat-message error-message">
                        <div class="message-meta"><strong>${t('net_error')}</strong></div>
                        <div class="message-content">${t('net_error_desc')}</div>
                    </div>`);
            } finally {
                queryInputChat.value = "";
                if (chatFileInput) chatFileInput.value = "";
                if (chatFileDisplay) chatFileDisplay.innerHTML = "";
                
                chatInputWrapper.classList.remove("locked");
                
                if (submitButton) {
                    submitButton.disabled = false;
                    submitButton.innerHTML = submitButton.dataset.originalText;
                }
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
        });
    }

    // --- 3. EDUCATIONAL LEAVES DYNAMIC FORM LOGIC (BILINGUAL) ---
    const staffCategorySelect = document.getElementById("staff_category");
    const leaveTypeSelect = document.getElementById("leave_type");
    const checklistContainer = document.getElementById("dynamic-checklist-container");
    const checklistContent = document.getElementById("checklist-content");

    if (staffCategorySelect && leaveTypeSelect && checklistContainer && checklistContent) {
        const leaveOptions = {
            dep: {
                el: [
                    {val: 'scientific', text: 'Επιστημονική Άδεια (Sabbatical)'},
                    {val: 'patent', text: 'Άδεια Κατοχύρωσης Ευρεσιτεχνίας'},
                    {val: 'unpaid', text: 'Άδεια Άνευ Αποδοχών (έως 3 έτη)'},
                    {val: 'international', text: 'Απόσπαση σε Διεθνή Οργανισμό'}
                ],
                en: [
                    {val: 'scientific', text: 'Sabbatical Leave'},
                    {val: 'patent', text: 'Patent Filing Leave'},
                    {val: 'unpaid', text: 'Leave Without Pay (up to 3 years)'},
                    {val: 'international', text: 'Secondment to International Organization'}
                ]
            },
            permanent: {
                el: [
                    {val: 'annual', text: 'Κανονική Άδεια'},
                    {val: 'sick', text: 'Αναρρωτική Άδεια'},
                    {val: 'exams', text: 'Άδεια Εξετάσεων'},
                    {val: 'training', text: 'Άδεια Υπηρεσιακής Εκπαίδευσης'},
                    {val: 'scientific_event', text: 'Άδεια για Επιστημονικούς/Επιμορφωτικούς Λόγους'},
                    {val: 'family', text: 'Άδειες Οικογενειακών Γεγονότων (Γάμος, Αιμοδοσία κ.λπ.)'},
                    {val: 'parental', text: 'Άδειες Μητρότητας / Πατρότητας / Ανατροφής'},
                    {val: 'disability', text: 'Ειδικές Άδειες Νοσήματος / Αναπηρίας'},
                    {val: 'unpaid', text: 'Άδειες Άνευ Αποδοχών (Σοβαροί λόγοι / Εξωτερικό)'}
                ],
                en: [
                    {val: 'annual', text: 'Regular Annual Leave'},
                    {val: 'sick', text: 'Sick Leave'},
                    {val: 'exams', text: 'Exam Leave'},
                    {val: 'training', text: 'In-service Training Leave'},
                    {val: 'scientific_event', text: 'Scientific / Training Conference Leave'},
                    {val: 'family', text: 'Family Event Leave (Marriage, Blood Donation, etc.)'},
                    {val: 'parental', text: 'Maternity / Paternity / Childcare Leave'},
                    {val: 'disability', text: 'Special Illness / Disability Leave'},
                    {val: 'unpaid', text: 'Leave Without Pay (Personal reasons / Abroad)'}
                ]
            },
            contract: {
                el: [
                    {val: 'annual', text: 'Κανονική Άδεια (λόγοι εξαιρετικής ανάγκης)'},
                    {val: 'sick', text: 'Αναρρωτική Άδεια'},
                    {val: 'exams', text: 'Άδεια Εξετάσεων'},
                    {val: 'scientific_event', text: 'Άδεια Επιστημονικών/Επιμορφωτικών Λόγων'},
                    {val: 'family', text: 'Άδειες Οικογενειακών Γεγονότων (Γάμος, Αιμοδοσία κ.λπ.)'},
                    {val: 'parental', text: 'Άδειες Μητρότητας / Πατρότητας / Γονική'},
                    {val: 'child_sick', text: 'Άδεια Ασθένειας / Νοσηλείας Τέκνου'}
                ],
                en: [
                    {val: 'annual', text: 'Regular Annual Leave (exceptional needs)'},
                    {val: 'sick', text: 'Sick Leave'},
                    {val: 'exams', text: 'Exam Leave'},
                    {val: 'scientific_event', text: 'Scientific / Training Conference Leave'},
                    {val: 'family', text: 'Family Event Leave (Marriage, Blood Donation, etc.)'},
                    {val: 'parental', text: 'Maternity / Paternity / Parental Leave'},
                    {val: 'child_sick', text: 'Child Illness / Hospitalization Leave'}
                ]
            }
        };

        const checklistTexts = {
            dep: {
                el: "<strong>Υποχρεωτικά έγγραφα (ενδεικτικά):</strong><br>&bull; Τεκμηριωμένη Αίτηση μέλους ΔΕΠ<br>&bull; Προτεινόμενο Πρόγραμμα Δραστηριότητας<br>&bull; Επίσημη Πρόσκληση Φορέα (εφόσον απαιτείται)<br>&bull; Βεβαίωση Χρόνου Υπηρεσίας από το Διοικητικό.",
                en: "<strong>Mandatory documents (indicative):</strong><br>&bull; Formal Faculty Member Application<br>&bull; Proposed Scientific Activity Program<br>&bull; Official Host Institution Invitation Letter (if required)<br>&bull; Length of Service Certificate from Administration."
            },
            permanent: {
                el: "<strong>Υποχρεωτικά έγγραφα (ενδεικτικά):</strong><br>&bull; Αίτηση Υπαλλήλου<br>&bull; Αποδεικτικό γεγονότος (π.χ. Ιατρική Γνωμάτευση, Βεβαίωση Σπουδών, Ληξιαρχική Πράξη)<br>&bull; Πιστοποιητικό Οικογενειακής Κατάστασης (για γονικές/οικογενειακές άδειες).",
                en: "<strong>Mandatory documents (indicative):</strong><br>&bull; Employee Application<br>&bull; Event verification document (e.g. Medical Certificate, Study Certificate, Civil Registry Act)<br>&bull; Family Status Certificate (for parental/family leaves)."
            },
            contract: {
                el: "<strong>Υποχρεωτικά έγγραφα (ενδεικτικά):</strong><br>&bull; Αίτηση Αναπληρωτή / Συμβασιούχου<br>&bull; Αντίγραφο Σύμβασης Εργασίας ΙΔΟΧ (για αναλογικό υπολογισμό ημερών)<br>&bull; Αποδεικτικό γεγονότος (π.χ. Ιατρική βεβαίωση, Βεβαίωση σπουδών).",
                en: "<strong>Mandatory documents (indicative):</strong><br>&bull; Contract Staff Application<br>&bull; Copy of Fixed-Term Employment Contract (for proportional day calculation)<br>&bull; Event verification document (e.g. Medical note, Study certificate)."
            }
        };

        staffCategorySelect.addEventListener("change", function() {
            const selectedCategory = this.value;
            
            leaveTypeSelect.innerHTML = '<option value="" disabled selected>' + t('el_select_leave_ph') + '</option>';
            
            if (selectedCategory && leaveOptions[selectedCategory]) {
                leaveTypeSelect.disabled = false;
                
                const optionsList = leaveOptions[selectedCategory][currentLang] || leaveOptions[selectedCategory]['el'];
                optionsList.forEach(function(option) {
                    const newOption = document.createElement("option");
                    newOption.value = option.val;
                    newOption.text = option.text;
                    leaveTypeSelect.appendChild(newOption);
                });

                const reminderText = checklistTexts[selectedCategory][currentLang] || checklistTexts[selectedCategory]['el'];
                checklistContent.innerHTML = reminderText;
                checklistContainer.style.display = "block";
            } else {
                leaveTypeSelect.disabled = true;
                checklistContainer.style.display = "none";
            }
        });
    }

    // --- 4. FACULTY EXPERIENCE DYNAMIC CHECKLIST LOGIC (BILINGUAL) ---
    const sectorSelect = document.getElementById("sector");
    const facContainer = document.getElementById("fac-exp-checklist-container");
    const facPlaceholder = document.getElementById("fac-exp-checklist-placeholder");
    const facContent = document.getElementById("fac-exp-checklist-content");

    if (sectorSelect && facContent) {
        const facChecklists = {
            hei: {
                el: `<ul>
                    <li>Αίτηση Αναγνώρισης Προϋπηρεσίας & Υπεύθυνη Δήλωση Ν. 1599/1986.</li>
                    <li>Βεβαίωση Προϋπηρεσίας Φορέα / ΕΛΚΕ (έναρξη-λήξη, πλήρες/μειωμένο ωράριο, αντικείμενο).</li>
                    <li>Αντίγραφα Συμβάσεων Εργασίας / Έργου (ή Βεβαίωση Επιστημονικού Υπευθύνου για διδακτικό έργο).</li>
                    <li>Βεβαίωση Ασφαλιστικού Φορέα / e-ΕΦΚΑ (Αποσπάσματα Ατομικού Λογαριασμού).</li>
                    <li>Βεβαίωση Ισοτιμίας ΔΟΑΤΑΠ (αποκλειστικά εφόσον πρόκειται για Πανεπιστήμιο/Φορέα Εξωτερικού).</li>
                </ul>`,
                en: `<ul>
                    <li>Application for Recognition & Solemn Declaration (Law 1599/1986).</li>
                    <li>Employer / Research Account (ELKE) Experience Certificate (start-end dates, working hours, subject).</li>
                    <li>Copies of Employment / Service Contracts (or Principal Investigator Certificate for teaching).</li>
                    <li>Social Security Certificate / e-EFKA insurance statements.</li>
                    <li>DOATAP Recognition Certificate (mandatory for foreign Higher Education Institutions).</li>
                </ul>`
            },
            public: {
                el: `<ul>
                    <li>Αίτηση Αναγνώρισης Προϋπηρεσίας & Υπεύθυνη Δήλωση Ν. 1599/1986.</li>
                    <li>Βεβαίωση Προϋπηρεσίας Δημόσιου Φορέα (με αναγραφή σχέσης εργασίας ΙΔΟΧ/ΙΔΑΧ).</li>
                    <li>Αποφάσεις Πρόσληψης & Απόλυσης / Αποχώρησης.</li>
                    <li>Βεβαίωση e-ΕΦΚΑ / Αποσπάσματα Ατομικού Λογαριασμού Ασφάλισης.</li>
                </ul>`,
                en: `<ul>
                    <li>Application for Recognition & Solemn Declaration (Law 1599/1986).</li>
                    <li>Public Sector Experience Certificate (indicating fixed-term or indefinite status).</li>
                    <li>Appointment and Termination / Resignation Decisions.</li>
                    <li>Social Security Certificate / e-EFKA insurance statements.</li>
                </ul>`
            },
            private: {
                el: `<ul>
                    <li>Αίτηση Αναγνώρισης Προϋπηρεσίας & Υπεύθυνη Δήλωση Ν. 1599/1986.</li>
                    <li>Βεβαίωση Εργοδότη / Προϋπηρεσίας (με σαφή περιγραφή του αντικειμένου απασχόλησης).</li>
                    <li>Αντίγραφα Συμβάσεων Εργασίας ή Παροχής Υπηρεσιών.</li>
                    <li>Αποσπάσματα Ατομικού Λογαριασμού Ασφάλισης e-ΕΦΚΑ (για έλεγχο ορίου έως 7 έτη).</li>
                </ul>`,
                en: `<ul>
                    <li>Application for Recognition & Solemn Declaration (Law 1599/1986).</li>
                    <li>Employer Experience Certificate (with explicit job description).</li>
                    <li>Copies of Employment Contracts or Service Agreements.</li>
                    <li>Social Security Extracts / e-EFKA insurance statements (to verify the 7-year limit).</li>
                </ul>`
            }
        };

        function updateFacultyChecklist() {
            const val = sectorSelect.value;
            let key = "";
            if (val.includes("ΑΕΙ") || val.includes("Higher Education")) {
                key = "hei";
            } else if (val.includes("Δημόσιος") || val.includes("Public Sector")) {
                key = "public";
            } else if (val.includes("Ιδιωτικός") || val.includes("Private Sector")) {
                key = "private";
            }

            if (key && facChecklists[key]) {
                const htmlContent = facChecklists[key][currentLang] || facChecklists[key]['el'];
                facContent.innerHTML = htmlContent;
                if (facContainer) facContainer.style.display = "block";
                if (facPlaceholder) facPlaceholder.style.display = "none";
            } else {
                if (facContainer) facContainer.style.display = "none";
                if (facPlaceholder) facPlaceholder.style.display = "block";
            }
        }

        sectorSelect.addEventListener("change", updateFacultyChecklist);
        updateFacultyChecklist();
    }
});