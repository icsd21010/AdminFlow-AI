import io
from pathlib import Path
from uuid import uuid4

from docx import Document
from flask import Blueprint, current_app, render_template, request, send_from_directory, send_file

from config import allowed_file, safe_filename
from modules.press_release.service import generate_press_release
from utils import cleanup_files

bp = Blueprint("press_release", __name__)


@bp.route("/", methods=["GET", "POST"])
def press_release():
    if request.method == "GET":
        return render_template("press_release_form.html")

    subject = request.form.get("subject", "").strip()
    tone = request.form.get("tone", "").strip()
    include_title = request.form.get("include_title", "").strip()
    include_summary = request.form.get("include_summary", "").strip()
    notes = request.form.get("notes", "").strip()

    uploaded_file_paths = []
    uploaded_file_names = []
    skipped_file_names = []

    upload_folder = Path(current_app.config["PRESS_RELEASE_UPLOAD_FOLDER"])
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    for uploaded_file in request.files.getlist("files"):
        if not uploaded_file or not uploaded_file.filename:
            continue

        original_filename = safe_filename(uploaded_file.filename)

        if not allowed_file(original_filename):
            skipped_file_names.append(original_filename)
            continue

        unique_filename = f"{uuid4().hex}_{original_filename}"
        file_path = upload_folder / unique_filename

        uploaded_file.save(file_path)
        uploaded_file_paths.append(str(file_path))
        uploaded_file_names.append(original_filename)

    if not subject:
        return render_template(
            "press_release_form.html",
            error_message="The Subject field is required.",
            subject=subject,
            tone=tone,
            include_title=include_title,
            include_summary=include_summary,
            notes=notes,
            skipped_file_names=skipped_file_names,
        ), 400

    if not uploaded_file_paths:
        return render_template(
            "press_release_form.html",
            error_message=(
                "You must upload at least one allowed text or document file "
                "(.txt, .pdf, .docx)."
            ),
            subject=subject,
            tone=tone,
            include_title=include_title,
            include_summary=include_summary,
            notes=notes,
            skipped_file_names=skipped_file_names,
        ), 400

    try:
        generated_press_release = generate_press_release(
            subject=subject,
            tone=tone,
            include_title=include_title,
            include_summary=include_summary,
            notes=notes,
            uploaded_file_paths=uploaded_file_paths,
        )
    except ValueError as error:
        return render_template(
            "press_release_form.html",
            error_message=str(error),
            subject=subject,
            tone=tone,
            include_title=include_title,
            include_summary=include_summary,
            notes=notes,
            skipped_file_names=skipped_file_names,
        ), 400
    except Exception as error:
        return render_template(
            "press_release_form.html",
            error_message=(
                "A problem occurred while generating the press release. "
                f"Technical information: {error}"
            ),
            subject=subject,
            tone=tone,
            include_title=include_title,
            include_summary=include_summary,
            notes=notes,
            skipped_file_names=skipped_file_names,
        ), 500

    finally:
        # <--- ΠΡΟΣΘΗΚΗ: Καθαρίζει τα uploads αν υπήρξαν αρχεία
        if uploaded_file_paths:
            cleanup_files(uploaded_file_paths)

    output_filename = f"press_release_{uuid4().hex}.txt"
    output_path = output_folder / output_filename
    output_path.write_text(generated_press_release, encoding="utf-8")

    return render_template(
        "press_release_result.html",
        press_release=generated_press_release,
        output_filename=output_filename,
        subject=subject,
        tone=tone,
        include_title=include_title,
        include_summary=include_summary,
        notes=notes,
        uploaded_file_names=uploaded_file_names,
        skipped_file_names=skipped_file_names,
    )


@bp.route("/download/<output_filename>")
def download_press_release(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.endswith(".txt"):
        return "File not found.", 404

    if not (output_folder / output_filename).exists():
        return "File not found.", 404

    return send_from_directory(
        output_folder,
        output_filename,
        as_attachment=True,
        download_name="press_release.txt",
    )


@bp.route("/download_docx/<output_filename>")
def download_docx(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.endswith(".txt"):
        return "File not found.", 404

    file_path = output_folder / output_filename
    if not file_path.exists():
        return "File not found.", 404

    text_content = file_path.read_text(encoding="utf-8")

    doc = Document()
    for line in text_content.split('\n'):
        line_stripped = line.strip()
        if line_stripped.startswith('# '):
            doc.add_heading(line_stripped.replace('# ', ''), level=1)
        elif line_stripped.startswith('## '):
            doc.add_heading(line_stripped.replace('## ', ''), level=2)
        elif line_stripped.startswith('### '):
            doc.add_heading(line_stripped.replace('### ', ''), level=3)
        elif line_stripped:
            doc.add_paragraph(line_stripped)
        else:
            doc.add_paragraph("")

    file_stream = io.BytesIO()
    doc.save(file_stream)
    file_stream.seek(0)

    docx_filename = output_filename.replace('.txt', '.docx')
    return send_file(
        file_stream,
        as_attachment=True,
        download_name=docx_filename,
        mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    )