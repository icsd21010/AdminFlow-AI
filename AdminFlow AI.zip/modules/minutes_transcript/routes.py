from pathlib import Path
from uuid import uuid4

from flask import Blueprint, current_app, render_template, request, send_from_directory

from config import allowed_file, safe_filename
from modules.minutes_transcript.service import generate_minutes_transcript
from utils import cleanup_files

bp = Blueprint("minutes_transcript", __name__)


@bp.route("/", methods=["GET", "POST"])
def minutes_transcript():
    if request.method == "GET":
        return render_template("minutes-transcript_form.html")

    committee_name = request.form.get("committee_name", "").strip()
    meeting_number = request.form.get("meeting_number", "").strip()
    topic = request.form.get("topic", "").strip()
    institution_name = request.form.get("institution_name", "").strip()
    members_list = request.form.get("members_list", "").strip()

    uploaded_file_paths = []
    uploaded_file_names = []
    skipped_file_names = []

    # Φρόντισε να υπάρχει το MINUTES_TRANSCRIPT_UPLOAD_FOLDER στο config.py σου
    upload_folder = Path(current_app.config.get("MINUTES_TRANSCRIPT_UPLOAD_FOLDER", current_app.config["UPLOAD_FOLDER"] + "/minutes-transcript"))
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    for uploaded_file in request.files.getlist("files"):
        if not uploaded_file or not uploaded_file.filename:
            continue

        original_filename = safe_filename(uploaded_file.filename)

        if not allowed_file(original_filename):
            skipped_file_names.append(original_filename)
            continue

        unique_filename = f"{uuid4().hex}_{original_filename}"
        file_path = upload_folder / unique_filename

        uploaded_file.save(file_path)
        uploaded_file_paths.append(str(file_path))
        uploaded_file_names.append(original_filename)

    if not committee_name:
        return render_template(
            "minutes-transcript_form.html",
            error_message="The Committee / Organ Name field is required.",
            committee_name=committee_name,
            meeting_number=meeting_number,
            topic=topic,
            institution_name=institution_name,
            members_list=members_list,
            skipped_file_names=skipped_file_names,
        ), 400

    if not uploaded_file_paths:
        return render_template(
            "minutes-transcript_form.html",
            error_message=(
                "You must upload at least one allowed text or document file "
                "(.txt, .pdf, .docx)."
            ),
            committee_name=committee_name,
            meeting_number=meeting_number,
            topic=topic,
            institution_name=institution_name,
            members_list=members_list,
            skipped_file_names=skipped_file_names,
        ), 400

    try:
        generated_minutes = generate_minutes_transcript(
            committee_name=committee_name,
            meeting_number=meeting_number,
            topic=topic,
            institution_name=institution_name,
            members_list=members_list,
            uploaded_file_paths=uploaded_file_paths,
        )
    except ValueError as error:
        return render_template(
            "minutes-transcript_form.html",
            error_message=str(error),
            committee_name=committee_name,
            meeting_number=meeting_number,
            topic=topic,
            institution_name=institution_name,
            members_list=members_list,
            skipped_file_names=skipped_file_names,
        ), 400
    except Exception as error:
        return render_template(
            "minutes-transcript_form.html",
            error_message=(
                "A problem occurred while generating the meeting minutes. "
                f"Technical information: {error}"
            ),
            committee_name=committee_name,
            meeting_number=meeting_number,
            topic=topic,
            institution_name=institution_name,
            members_list=members_list,
            skipped_file_names=skipped_file_names,
        ), 500

    finally:
        # <--- ΠΡΟΣΘΗΚΗ: Καθαρίζει τα uploads αν υπήρξαν αρχεία
        if uploaded_file_paths:
            cleanup_files(uploaded_file_paths)

    output_filename = f"minutes_transcript_{uuid4().hex}.txt"
    output_path = output_folder / output_filename
    output_path.write_text(generated_minutes, encoding="utf-8")

    return render_template(
        "minutes-transcript_result.html",
        minutes_transcript=generated_minutes,
        output_filename=output_filename,
        committee_name=committee_name,
        meeting_number=meeting_number,
        topic=topic,
        institution_name=institution_name,
        members_list=members_list,
        uploaded_file_names=uploaded_file_names,
        skipped_file_names=skipped_file_names,
    )


@bp.route("/download/<output_filename>")
def download_minutes_transcript(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.startswith("minutes_transcript_") or not output_filename.endswith(
        ".txt"
    ):
        return "File not found.", 404

    if not (output_folder / output_filename).exists():
        return "File not found.", 404

    return send_from_directory(
        output_folder,
        output_filename,
        as_attachment=True,
        download_name="meeting_minutes.txt",
    )