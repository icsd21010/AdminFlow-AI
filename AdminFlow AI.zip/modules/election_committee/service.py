from pathlib import Path

from docx import Document
from openai import OpenAI
from pypdf import PdfReader

from config import OPENAI_API_KEY, OPENAI_MODEL


MODULE_DIR = Path(__file__).resolve().parent
REFERENCE_FILES_DIR = MODULE_DIR / "reference_files"

MAX_FILE_TEXT_LENGTH = 30000
MAX_REFERENCE_TEXT_LENGTH = 50000

SUPPORTED_TEXT_EXTENSIONS = {".txt", ".docx", ".doc", ".pdf"}


def read_text_file(file_path: Path) -> str:
    try:
        return file_path.read_text(encoding="utf-8").strip()
    except UnicodeDecodeError:
        return file_path.read_text(encoding="utf-8-sig").strip()


def read_docx_file(file_path: Path) -> str:
    document = Document(file_path)

    paragraphs = [
        paragraph.text.strip()
        for paragraph in document.paragraphs
        if paragraph.text.strip()
    ]

    table_rows = []

    for table in document.tables:
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            table_rows.append(" | ".join(cells))

    return "\n".join(paragraphs + table_rows).strip()


def read_pdf_file(file_path: Path) -> str:
    reader = PdfReader(str(file_path))
    pages_text = []

    for page in reader.pages:
        page_text = page.extract_text() or ""
        pages_text.append(page_text.strip())

    return "\n".join(pages_text).strip()


def read_supported_file(file_path: Path) -> str:
    suffix = file_path.suffix.lower()

    if suffix == ".txt":
        return read_text_file(file_path)

    if suffix == ".docx":
        return read_docx_file(file_path)

    if suffix == ".pdf":
        return read_pdf_file(file_path)

    return ""


def limit_text(text: str, maximum_length: int) -> str:
    if len(text) <= maximum_length:
        return text

    return (
        text[:maximum_length]
        + "\n\n[The remaining file content was not sent due to the size limit.]"
    )


def read_module_file(filename: str) -> str:
    file_path = MODULE_DIR / filename

    if not file_path.exists():
        return ""

    return read_supported_file(file_path)


def read_reference_file(filename: str) -> str:
    file_path = REFERENCE_FILES_DIR / filename

    if not file_path.exists():
        return ""

    return read_supported_file(file_path)


def read_uploaded_material(uploaded_file_paths: list[str]) -> str:
    sections = []

    for file_path_string in uploaded_file_paths:
        file_path = Path(file_path_string)

        if not file_path.exists():
            continue

        suffix = file_path.suffix.lower()

        if suffix not in SUPPORTED_TEXT_EXTENSIONS:
            continue

        try:
            content = read_supported_file(file_path)
        except Exception as error:
            sections.append(
                f"\n--- UPLOADED FILE: {file_path.name} ---\n"
                f"[Το αρχείο δεν μπόρεσε να διαβαστεί: {error}]"
            )
            continue

        if content:
            sections.append(
                f"\n--- ΥΛΙΚΟ ΧΡΗΣΤΗ (ΑΡΧΕΙΟ ΑΠΕΛΛΑ / ΠΡΑΚΤΙΚΟ): {file_path.name} ---\n{content}"
            )

    return limit_text("\n".join(sections).strip(), MAX_FILE_TEXT_LENGTH)


def build_instructions() -> str:
    prompt = read_module_file("Instructions election_committee.txt")
    regulations = read_reference_file("regulations.txt")
    apella_sample = read_reference_file("apella_sample.txt")
    output_template = read_reference_file("output_template.txt")
    examples = read_module_file("examples.txt")

    instructions_sections = [
        "APPLICATION: Σύνταξη Διοικητικής Πράξης - Συγκρότηση Εκλεκτορικού Σώματος",
        prompt,
    ]

    if regulations:
        instructions_sections.append(
            "\n## ΝΟΜΟΘΕΣΙΑ / ΚΑΝΟΝΙΣΜΟΙ (REGULATIONS)\n"
            f"{regulations}"
        )

    if apella_sample:
        instructions_sections.append(
            "\n## ΟΔΗΓΟΣ ΑΝΑΓΝΩΣΗΣ ΑΡΧΕΙΩΝ ΑΠΕΛΛΑ (REFERENCE FILE)\n"
            f"{apella_sample}"
        )

    if output_template:
        instructions_sections.append(
            "\n## OUTPUT TEMPLATE (ΑΥΣΤΗΡΟ ΠΡΟΤΥΠΟ ΕΞΟΔΟΥ)\n"
            "Χρησιμοποίησε ΑΥΣΤΗΡΑ αυτή τη δομή για την απάντησή σου.\n"
            f"{output_template}"
        )

    if examples:
        instructions_sections.append(
            "\n## ΠΑΡΑΔΕΙΓΜΑΤΑ ΧΡΗΣΗΣ (FEW-SHOT EXAMPLES)\n"
            f"{examples}"
        )

    return "\n\n".join(
        section for section in instructions_sections if section.strip()
    ).strip()


def build_user_input(
    meeting_number: str,
    meeting_date: str,
    uploaded_material: str,
) -> str:

    return f"""
## ΠΑΡΑΜΕΤΡΟΙ ΧΡΗΣΤΗ (USER PARAMETERS)

- Αριθμός Συνεδρίασης (Meeting Number): {meeting_number if meeting_number else "[Δεν δηλώθηκε]"}
- Ημερομηνία Συνεδρίασης (Meeting Date): {meeting_date if meeting_date else "[Δεν δηλώθηκε]"}


## ΥΛΙΚΟ ΠΡΟΣ ΑΝΑΛΥΣΗ (ΑΡΧΕΙΑ ΑΠΕΛΛΑ / ΠΡΑΚΤΙΚΟ)

{uploaded_material if uploaded_material else "[Δεν ανέβηκε αναγνώσιμο αρχείο κειμένου.]"}


## ΕΡΓΑΣΙΑ (TASK)

Βάσει του υλικού προς ανάλυση και των παραμέτρων που δόθηκαν, συνέταξε τη Διοικητική Πράξη Συγκρότησης Εκλεκτορικού Σώματος ακολουθώντας αυστηρά το Output Template, τους Κανονισμούς και τον Οδηγό Ανάγνωσης. 
Μην επινοείς στοιχεία. Αν κάτι λείπει, συμπλήρωσε "[Δεν αναγράφεται]" και κατέγραψέ το στις Παρατηρήσεις.
""".strip()


def generate_election_committee_act(
    meeting_number: str,
    meeting_date: str,
    uploaded_file_paths: list[str],
) -> str:
    if not OPENAI_API_KEY:
        raise ValueError("OPENAI_API_KEY is not set in the .env file.")
    if not OPENAI_API_KEY.startswith("sk-"):
        raise ValueError("OPENAI_API_KEY in the .env file does not look valid.")

    try:
        OPENAI_API_KEY.encode("ascii")
    except UnicodeEncodeError:
        raise ValueError(
            "OPENAI_API_KEY contains non-ASCII characters. "
            "Please retype it in the .env file without smart quotes or hidden characters."
        )

    instructions = build_instructions()
    uploaded_material = read_uploaded_material(uploaded_file_paths)

    user_input = build_user_input(
        meeting_number=meeting_number,
        meeting_date=meeting_date,
        uploaded_material=uploaded_material,
    )

    client = OpenAI(api_key=OPENAI_API_KEY)

    response = client.responses.create(
        model=OPENAI_MODEL,
        instructions=instructions,
        input=user_input,
    )

    return response.output_text.strip()