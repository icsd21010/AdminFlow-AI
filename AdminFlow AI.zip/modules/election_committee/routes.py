import io
from pathlib import Path
from uuid import uuid4

from docx import Document
from flask import Blueprint, current_app, render_template, request, send_from_directory, send_file

from config import allowed_file, safe_filename
from modules.election_committee.service import generate_election_committee_act
from utils import cleanup_files

bp = Blueprint("election_committee", __name__)


@bp.route("/", methods=["GET", "POST"])
def election_committee():
    if request.method == "GET":
        return render_template("election-committee_form.html")

    meeting_number = request.form.get("meeting_number", "").strip()
    meeting_date = request.form.get("meeting_date", "").strip()

    uploaded_file_paths = []
    uploaded_file_names = []
    skipped_file_names = []

    # Requires ELECTION_COMMITTEE_UPLOAD_FOLDER to be set in config.py
    upload_folder = Path(current_app.config.get("ELECTION_COMMITTEE_UPLOAD_FOLDER", current_app.config["UPLOAD_FOLDER"] + "/election-committee"))
    upload_folder.mkdir(parents=True, exist_ok=True)
    
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])
    output_folder.mkdir(parents=True, exist_ok=True)

    for uploaded_file in request.files.getlist("files"):
        if not uploaded_file or not uploaded_file.filename:
            continue

        original_filename = safe_filename(uploaded_file.filename)

        if not allowed_file(original_filename):
            skipped_file_names.append(original_filename)
            continue

        unique_filename = f"{uuid4().hex}_{original_filename}"
        file_path = upload_folder / unique_filename

        uploaded_file.save(file_path)
        uploaded_file_paths.append(str(file_path))
        uploaded_file_names.append(original_filename)

    if not uploaded_file_paths:
        return render_template(
            "election-committee_form.html",
            error_message=(
                "Πρέπει να ανεβάσετε τουλάχιστον ένα επιτρεπτό αρχείο "
                "(.txt, .pdf, .docx) από το ΑΠΕΛΛΑ ή το Πρακτικό Συνέλευσης."
            ),
            meeting_number=meeting_number,
            meeting_date=meeting_date,
            skipped_file_names=skipped_file_names,
        ), 400

    try:
        generated_document = generate_election_committee_act(
            meeting_number=meeting_number,
            meeting_date=meeting_date,
            uploaded_file_paths=uploaded_file_paths,
        )
    except ValueError as error:
        return render_template(
            "election-committee_form.html",
            error_message=str(error),
            meeting_number=meeting_number,
            meeting_date=meeting_date,
            skipped_file_names=skipped_file_names,
        ), 400
    except Exception as error:
        return render_template(
            "election-committee_form.html",
            error_message=(
                "Προέκυψε ένα τεχνικό σφάλμα κατά τη σύνταξη της Πράξης Συγκρότησης. "
                f"Τεχνικές πληροφορίες: {error}"
            ),
            meeting_number=meeting_number,
            meeting_date=meeting_date,
            skipped_file_names=skipped_file_names,
        ), 500

    finally:
        # <--- ΠΡΟΣΘΗΚΗ: Καθαρίζει τα uploads αν υπήρξαν αρχεία
        if uploaded_file_paths:
            cleanup_files(uploaded_file_paths)

    output_filename = f"praxi_sygkrotisis_{uuid4().hex}.txt"
    output_path = output_folder / output_filename
    output_path.write_text(generated_document, encoding="utf-8")

    return render_template(
        "election-committee_result.html",
        generated_document=generated_document,
        output_filename=output_filename,
        meeting_number=meeting_number,
        meeting_date=meeting_date,
        uploaded_file_names=uploaded_file_names,
        skipped_file_names=skipped_file_names,
    )


@bp.route("/download/<output_filename>")
def download_election_committee_act(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.endswith(".txt"):
        return "File not found.", 404

    if not (output_folder / output_filename).exists():
        return "File not found.", 404

    return send_from_directory(
        output_folder,
        output_filename,
        as_attachment=True,
        download_name="praxi_sygkrotisis.txt",
    )


@bp.route("/download_docx/<output_filename>")
def download_docx(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.endswith(".txt"):
        return "File not found.", 404

    file_path = output_folder / output_filename
    if not file_path.exists():
        return "File not found.", 404

    text_content = file_path.read_text(encoding="utf-8")

    doc = Document()
    for line in text_content.split('\n'):
        line_stripped = line.strip()
        if line_stripped.startswith('# '):
            doc.add_heading(line_stripped.replace('# ', ''), level=1)
        elif line_stripped.startswith('## '):
            doc.add_heading(line_stripped.replace('## ', ''), level=2)
        elif line_stripped.startswith('### '):
            doc.add_heading(line_stripped.replace('### ', ''), level=3)
        elif line_stripped:
            doc.add_paragraph(line_stripped)
        else:
            doc.add_paragraph("")

    file_stream = io.BytesIO()
    doc.save(file_stream)
    file_stream.seek(0)

    docx_filename = output_filename.replace('.txt', '.docx')
    return send_file(
        file_stream,
        as_attachment=True,
        download_name=docx_filename,
        mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    )