import os
from pathlib import Path
from uuid import uuid4

from flask import Blueprint, current_app, render_template, request, send_from_directory

from config import allowed_file, safe_filename
from modules.check_graduation_requirements.service import generate_check_graduation_requirements

# ΕΙΣΑΓΩΓΗ ΤΗΣ ΣΥΝΑΡΤΗΣΗΣ ΚΑΘΑΡΙΣΜΟΥ ΑΠΟ ΤΟ ΚΕΝΤΡΙΚΟ APP
from utils import cleanup_files

bp = Blueprint("check_graduation_requirements", __name__)

@bp.route("/", methods=["GET", "POST"])
def check_graduation_requirements():
    if request.method == "GET":
        return render_template("check_graduation_requirements_form.html")

    entry_year = request.form.get("entry_year", "").strip()

    uploaded_file_paths = []
    uploaded_file_names = []
    skipped_file_names = []

    upload_folder = Path(current_app.config.get(
        "CHECK_GRADUATION_REQUIREMENTS_UPLOAD_FOLDER", 
        current_app.config["UPLOAD_FOLDER"] + "/check-graduation-requirements"
    ))
    upload_folder.mkdir(parents=True, exist_ok=True)
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    for uploaded_file in request.files.getlist("files"):
        if not uploaded_file or not uploaded_file.filename:
            continue

        original_filename = safe_filename(uploaded_file.filename)

        if not allowed_file(original_filename):
            skipped_file_names.append(original_filename)
            continue

        unique_filename = f"{uuid4().hex}_{original_filename}"
        file_path = upload_folder / unique_filename

        uploaded_file.save(file_path)
        uploaded_file_paths.append(str(file_path))
        uploaded_file_names.append(original_filename)

    if not uploaded_file_paths:
        return render_template(
            "check_graduation_requirements_form.html",
            error_message="Πρέπει να μεταφορτώσετε το αρχείο της Αναλυτικής Βαθμολογίας για τον έλεγχο.",
            entry_year=entry_year,
            skipped_file_names=skipped_file_names,
        ), 400

    # ΤΥΦΛΟΣΟΥΡΤΗΣ: ΕΔΩ ΜΠΑΙΝΕΙ Η ΔΟΜΗ TRY... FINALLY ΓΙΑ ΝΑ ΣΒΗΝΟΝΤΑΙ ΤΑ ΑΡΧΕΙΑ
    try:
        generated_report = generate_check_graduation_requirements(
            entry_year=entry_year,
            uploaded_file_paths=uploaded_file_paths,
        )
    except ValueError as error:
        return render_template(
            "check_graduation_requirements_form.html",
            error_message=str(error),
            entry_year=entry_year,
            skipped_file_names=skipped_file_names,
        ), 400
    except Exception as error:
        return render_template(
            "check_graduation_requirements_form.html",
            error_message=(
                "Παρουσιάστηκε πρόβλημα κατά τον έλεγχο της βαθμολογίας. "
                f"Τεχνικές πληροφορίες: {error}"
            ),
            entry_year=entry_year,
            skipped_file_names=skipped_file_names,
        ), 500
    finally:
        # Αυτό εκτελείται ΠΑΝΤΑ, είτε πετύχει το LLM είτε βγάλει σφάλμα. 
        # Καθαρίζει τα αρχεία που ανέβασε ο χρήστης αμέσως.
        cleanup_files(uploaded_file_paths)

    # Τα outputs αποθηκεύονται κανονικά. Θα τα σκουπίσει ο Garbage Collector 
    # μετά από 30 λεπτά, ώστε να προλάβει να τα κατεβάσει ο χρήστης.
    output_filename = f"graduation_report_{uuid4().hex}.txt"
    output_path = output_folder / output_filename
    output_path.write_text(generated_report, encoding="utf-8")

    return render_template(
        "check_graduation_requirements_result.html",
        report=generated_report,
        output_filename=output_filename,
        entry_year=entry_year,
        uploaded_file_names=uploaded_file_names,
        skipped_file_names=skipped_file_names,
    )

@bp.route("/download/<output_filename>")
def download_report(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.startswith("graduation_report_") or not output_filename.endswith(".txt"):
        return "File not found.", 404

    if not (output_folder / output_filename).exists():
        return "File not found.", 404

    return send_from_directory(
        output_folder,
        output_filename,
        as_attachment=True,
        download_name="graduation_requirements_report.txt",
    )