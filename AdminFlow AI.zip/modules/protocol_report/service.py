import tempfile
import zipfile
from pathlib import Path

import pandas as pd
from docx import Document
from openai import OpenAI
from pypdf import PdfReader

from config import OPENAI_API_KEY, OPENAI_MODEL


MODULE_DIR = Path(__file__).resolve().parent
EXAMPLES_DIR = MODULE_DIR / "examples"
REFERENCE_FILES_DIR = MODULE_DIR / "reference_files"

MAX_FILE_TEXT_LENGTH = 30000
MAX_REFERENCE_TEXT_LENGTH = 50000

SUPPORTED_TEXT_EXTENSIONS = {".txt", ".pdf", ".docx", ".doc", ".xls", ".xlsx", ".zip"}


def read_text_file(file_path: Path) -> str:
    try:
        return file_path.read_text(encoding="utf-8").strip()
    except UnicodeDecodeError:
        return file_path.read_text(encoding="utf-8-sig").strip()


def read_docx_file(file_path: Path) -> str:
    document = Document(file_path)

    paragraphs = [
        paragraph.text.strip()
        for paragraph in document.paragraphs
        if paragraph.text.strip()
    ]

    table_rows = []

    for table in document.tables:
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            table_rows.append(" | ".join(cells))

    return "\n".join(paragraphs + table_rows).strip()


def read_pdf_file(file_path: Path) -> str:
    reader = PdfReader(str(file_path))
    pages_text = []

    for page in reader.pages:
        page_text = page.extract_text() or ""
        pages_text.append(page_text.strip())

    return "\n".join(pages_text).strip()


def read_excel_file(file_path: Path) -> str:
    try:
        # Μετατρέπει το Excel σε DataFrame και μετά σε καθαρό string μορφής πίνακα
        df = pd.read_excel(file_path)
        return df.to_string(index=False)
    except Exception as e:
        return f"[Αδυναμία ανάγνωσης αρχείου Excel: {str(e)}]"

def read_zip_file(file_path: Path) -> str:
    extracted_sections = []
    try:
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            with zipfile.ZipFile(file_path, "r") as zip_ref:
                zip_ref.extractall(temp_path)

            for extracted_file in sorted(temp_path.rglob("*")):
                if extracted_file.is_file():
                    # Αγνόηση κρυφών αρχείων συστήματος (.DS_Store, __MACOSX)
                    if extracted_file.name.startswith(".") or "__MACOSX" in extracted_file.parts:
                        continue

                    suffix = extracted_file.suffix.lower()
                    if suffix in {".txt", ".docx", ".doc", ".pdf"}:
                        content = read_supported_file(extracted_file)
                        if content:
                            extracted_sections.append(
                                f"\n--- ΑΡΧΕΙΟ ΑΠΟ ZIP ({file_path.name} -> {extracted_file.relative_to(temp_path)}): ---\n{content}"
                            )
    except Exception as error:
        return f"[Σφάλμα κατά την αποσυμπίεση/ανάγνωση του αρχείου ZIP ({file_path.name}): {error}]"

    return "\n".join(extracted_sections).strip()

def read_supported_file(file_path: Path) -> str:
    suffix = file_path.suffix.lower()

    if suffix == ".txt":
        return read_text_file(file_path)

    if suffix == ".docx":
        return read_docx_file(file_path)

    if suffix == ".pdf":
        return read_pdf_file(file_path)
        
    if suffix in {".xls", ".xlsx"}:
        return read_excel_file(file_path)

    if suffix == ".zip":
        return read_zip_file(file_path)

    return ""


def limit_text(text: str, maximum_length: int) -> str:
    if len(text) <= maximum_length:
        return text

    return (
        text[:maximum_length]
        + "\n\n[Το υπόλοιπο περιεχόμενο του αρχείου παραλείφθηκε λόγω μεγέθους.]"
    )


def read_module_file(filename: str) -> str:
    file_path = MODULE_DIR / filename

    if not file_path.exists():
        return ""

    return read_supported_file(file_path)


def read_reference_file(filename: str) -> str:
    file_path = REFERENCE_FILES_DIR / filename

    if not file_path.exists():
        return ""

    return read_supported_file(file_path)


def read_example_file(filename: str) -> str:
    file_path = EXAMPLES_DIR / filename

    if not file_path.exists():
        return ""

    return read_supported_file(file_path)


def read_uploaded_material(uploaded_file_paths: list[str]) -> str:
    sections = []

    for file_path_string in uploaded_file_paths:
        file_path = Path(file_path_string)

        if not file_path.exists():
            continue

        suffix = file_path.suffix.lower()

        if suffix not in SUPPORTED_TEXT_EXTENSIONS:
            continue

        try:
            content = read_supported_file(file_path)
        except Exception as error:
            sections.append(
                f"\n--- UPLOADED FILE: {file_path.name} ---\n"
                f"[Το αρχείο δεν μπόρεσε να διαβαστεί: {error}]"
            )
            continue

        if content:
            sections.append(
                f"\n--- ΥΛΙΚΟ ΧΡΗΣΤΗ (ΑΡΧΕΙΟ ΠΡΩΤΟΚΟΛΛΟΥ): {file_path.name} ---\n{content}"
            )

    return limit_text("\n".join(sections).strip(), MAX_FILE_TEXT_LENGTH)


def build_instructions() -> str:
    prompt = read_module_file("Instructions protocol_report.txt")
    guidelines = read_reference_file("protocol_report_guidelines.txt")
    output_template = read_reference_file("output_template.txt")
    output_examples = read_example_file("output_examples.txt")

    instructions_sections = [
        "APPLICATION: Σύνθεση Διοικητικής Έκθεσης Πρωτοκόλλου",
        prompt,
    ]

    if guidelines:
        instructions_sections.append(
            "\n## ΟΔΗΓΙΕΣ ΣΥΝΤΑΞΗΣ (REFERENCE FILE)\n"
            f"{limit_text(guidelines, MAX_REFERENCE_TEXT_LENGTH)}"
        )

    if output_template:
        instructions_sections.append(
            "\n## OUTPUT TEMPLATE (ΑΥΣΤΗΡΟ ΠΡΟΤΥΠΟ ΕΞΟΔΟΥ)\n"
            f"{limit_text(output_template, MAX_REFERENCE_TEXT_LENGTH)}"
        )

    if output_examples:
        instructions_sections.append(
            "\n## ΠΑΡΑΔΕΙΓΜΑΤΑ ΧΡΗΣΗΣ (FEW-SHOT EXAMPLES)\n"
            f"{limit_text(output_examples, MAX_REFERENCE_TEXT_LENGTH)}"
        )

    return "\n\n".join(
        section for section in instructions_sections if section.strip()
    ).strip()


def build_user_input(
    department: str,
    report_type: str,
    uploaded_material: str,
) -> str:
    return f"""
## ΠΑΡΑΜΕΤΡΟΙ ΧΡΗΣΤΗ (USER SETTINGS)

- Τμήμα / Μονάδα: {department if department else "[Δεν δηλώθηκε - Χρήση προεπιλογής]"}
- Τύπος Έκθεσης: {report_type if report_type else "[Δεν δηλώθηκε - Θεώρησε ως Ημερήσια]"}

## ΥΛΙΚΟ ΠΡΟΣ ΑΝΑΛΥΣΗ (ΔΕΔΟΜΕΝΑ ΠΡΩΤΟΚΟΛΛΟΥ)

{uploaded_material if uploaded_material else "[Δεν βρέθηκε υλικό προς ανάλυση.]"}

## ΕΡΓΑΣΙΑ (TASK)

Βάσει του αρχείου πρωτοκόλλου και των παραμέτρων που δόθηκαν, συνέταξε τη Διοικητική Έκθεση Πεπραγμένων ακολουθώντας αυστηρά το Output Template και τις Οδηγίες Σύνταξης. 
Φρόντισε να ομαδοποιήσεις τις εγγραφές και να εντοπίσεις με ακρίβεια τις εκκρεμότητες και τα κρίσιμα θέματα. 
Μην επινοείς γεγονότα και αριθμούς πρωτοκόλλου που δεν υπάρχουν στο αρχείο εισόδου.
""".strip()


def generate_protocol_report(
    department: str,
    report_type: str,
    uploaded_file_paths: list[str],
) -> str:
    if not OPENAI_API_KEY:
        raise ValueError(
            "OPENAI_API_KEY is not set in the .env file."
            )
    if not OPENAI_API_KEY.startswith("sk-"):
        raise ValueError("OPENAI_API_KEY in the .env file does not look valid.")

    try:
        OPENAI_API_KEY.encode("ascii")
    except UnicodeEncodeError:
        raise ValueError(
            "OPENAI_API_KEY contains non-ASCII characters. "
            "Please retype it in the .env file without smart quotes or hidden characters."
        )

    instructions = build_instructions()
    uploaded_material = read_uploaded_material(uploaded_file_paths)

    user_input = build_user_input(
        department=department,
        report_type=report_type,
        uploaded_material=uploaded_material,
    )

    client = OpenAI(api_key=OPENAI_API_KEY)

    response = client.responses.create(
        model=OPENAI_MODEL,
        instructions=instructions,
        input=user_input,
    )

    return response.output_text.strip()