import io
from pathlib import Path
from uuid import uuid4

from docx import Document
from flask import Blueprint, current_app, render_template, request, send_from_directory, send_file

from config import allowed_file, safe_filename
from modules.certificate_teaching.service import generate_certificate_teaching
from utils import cleanup_files

bp = Blueprint("certificate_teaching", __name__)


@bp.route("/", methods=["GET", "POST"])
def certificate_teaching():
    if request.method == "GET":
        return render_template("certificate-teaching_form.html")

    # Flow Settings
    input_method = request.form.get("input_method", "file").strip()
    production_mode = request.form.get("production_mode", "single").strip()
    
    # File Flow Fields
    target_instructor_single = request.form.get("target_instructor_single", "").strip()
    target_instructor_mass = request.form.get("target_instructor_mass", "").strip()
    
    target_instructors = target_instructor_mass if production_mode == "mass" else target_instructor_single

    # Manual Flow Fields
    instructor_name = request.form.get("instructor_name", "").strip()
    academic_year = request.form.get("academic_year", "").strip()
    semester = request.form.get("semester", "").strip()
    course = request.form.get("course", "").strip()
    role = request.form.get("role", "").strip()

    uploaded_file_paths = []
    uploaded_file_names = []
    skipped_file_names = []

    upload_folder = Path(current_app.config.get("CERTIFICATE_TEACHING_UPLOAD_FOLDER", current_app.config["UPLOAD_FOLDER"] + "/certificate-teaching"))
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    # Security check: Manual + Mass is invalid
    if input_method == "manual" and production_mode == "mass":
        return render_template(
            "certificate-teaching_form.html",
            error_message="Mass generation is not supported with Manual entry. Please upload a file.",
            input_method=input_method,
            production_mode="single", # fallback
        ), 400

    # Process files ONLY if input_method is 'file'
    if input_method == "file":
        for uploaded_file in request.files.getlist("files"):
            if not uploaded_file or not uploaded_file.filename:
                continue

            original_filename = safe_filename(uploaded_file.filename)

            if not allowed_file(original_filename):
                skipped_file_names.append(original_filename)
                continue

            unique_filename = f"{uuid4().hex}_{original_filename}"
            file_path = upload_folder / unique_filename

            uploaded_file.save(file_path)
            uploaded_file_paths.append(str(file_path))
            uploaded_file_names.append(original_filename)

        if not uploaded_file_paths:
            return render_template(
                "certificate-teaching_form.html",
                error_message="You must upload an assignments file when 'Extract from file' is selected.",
                input_method=input_method,
                production_mode=production_mode,
                target_instructor_single=target_instructor_single,
                target_instructor_mass=target_instructor_mass,
            ), 400
            
        if not target_instructors:
            return render_template(
                "certificate-teaching_form.html",
                error_message="You must specify the target instructor(s) when extracting from a file.",
                input_method=input_method,
                production_mode=production_mode,
            ), 400

    # Process manual inputs ONLY if input_method is 'manual'
    if input_method == "manual":
        if not instructor_name:
            return render_template(
                "certificate-teaching_form.html",
                error_message="Instructor Name is required for manual entry.",
                input_method=input_method,
                production_mode=production_mode,
                instructor_name=instructor_name,
                academic_year=academic_year,
                semester=semester,
                course=course,
                role=role,
            ), 400

    try:
        generated_certificate = generate_certificate_teaching(
            input_method=input_method,
            production_mode=production_mode,
            target_instructors=target_instructors,
            instructor_name=instructor_name,
            academic_year=academic_year,
            semester=semester,
            course=course,
            role=role,
            uploaded_file_paths=uploaded_file_paths,
        )
    except ValueError as error:
        return render_template(
            "certificate-teaching_form.html",
            error_message=str(error),
            input_method=input_method,
            production_mode=production_mode,
        ), 400
    except Exception as error:
        return render_template(
            "certificate-teaching_form.html",
            error_message=(
                "A problem occurred while generating the certificate. "
                f"Technical information: {error}"
            ),
            input_method=input_method,
            production_mode=production_mode,
        ), 500
    
    finally:
        # <--- ΠΡΟΣΘΗΚΗ: Καθαρίζει τα uploads αν υπήρξαν αρχεία
        if uploaded_file_paths:
            cleanup_files(uploaded_file_paths)

    output_filename = f"certificate_{uuid4().hex}.txt"
    output_path = output_folder / output_filename
    output_path.write_text(generated_certificate, encoding="utf-8")

    return render_template(
        "certificate-teaching_result.html",
        certificate=generated_certificate,
        output_filename=output_filename,
        input_method=input_method,
        production_mode=production_mode,
        target_instructors=target_instructors if input_method == "file" else instructor_name,
        uploaded_file_names=uploaded_file_names,
        skipped_file_names=skipped_file_names,
    )


@bp.route("/download/<output_filename>")
def download_certificate(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.endswith(".txt"):
        return "File not found.", 404

    if not (output_folder / output_filename).exists():
        return "File not found.", 404

    return send_from_directory(
        output_folder,
        output_filename,
        as_attachment=True,
        download_name="teaching_certificate.txt",
    )


@bp.route("/download_docx/<output_filename>")
def download_docx(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.endswith(".txt"):
        return "File not found.", 404

    file_path = output_folder / output_filename
    if not file_path.exists():
        return "File not found.", 404

    text_content = file_path.read_text(encoding="utf-8")

    doc = Document()
    for line in text_content.split('\n'):
        line_stripped = line.strip()
        if line_stripped.startswith('# '):
            doc.add_heading(line_stripped.replace('# ', ''), level=1)
        elif line_stripped.startswith('## '):
            doc.add_heading(line_stripped.replace('## ', ''), level=2)
        elif line_stripped.startswith('### '):
            doc.add_heading(line_stripped.replace('### ', ''), level=3)
        elif line_stripped:
            doc.add_paragraph(line_stripped)
        else:
            doc.add_paragraph("")

    file_stream = io.BytesIO()
    doc.save(file_stream)
    file_stream.seek(0)

    docx_filename = output_filename.replace('.txt', '.docx')
    return send_file(
        file_stream,
        as_attachment=True,
        download_name=docx_filename,
        mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    )