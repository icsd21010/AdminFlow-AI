from pathlib import Path

from docx import Document
from openai import OpenAI
import pandas as pd
from pypdf import PdfReader

from config import OPENAI_API_KEY, OPENAI_MODEL


MODULE_DIR = Path(__file__).resolve().parent
EXAMPLES_DIR = MODULE_DIR / "examples"
REFERENCE_FILES_DIR = MODULE_DIR / "reference_files"

MAX_FILE_TEXT_LENGTH = 30000
MAX_REFERENCE_TEXT_LENGTH = 50000

SUPPORTED_TEXT_EXTENSIONS = {".txt", ".docx", ".pdf", ".xlsx", ".xls"}


def read_text_file(file_path: Path) -> str:
    try:
        return file_path.read_text(encoding="utf-8").strip()
    except UnicodeDecodeError:
        return file_path.read_text(encoding="utf-8-sig").strip()


def read_docx_file(file_path: Path) -> str:
    document = Document(file_path)

    paragraphs = [
        paragraph.text.strip()
        for paragraph in document.paragraphs
        if paragraph.text.strip()
    ]

    table_rows = []

    for table in document.tables:
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            table_rows.append(" | ".join(cells))

    return "\n".join(paragraphs + table_rows).strip()


def read_pdf_file(file_path: Path) -> str:
    reader = PdfReader(str(file_path))
    pages_text = []

    for page in reader.pages:
        page_text = page.extract_text() or ""
        pages_text.append(page_text.strip())

    return "\n".join(pages_text).strip()


def read_excel_file(file_path: Path) -> str:
    try:
        df = pd.read_excel(file_path)
        return df.to_string(index=False)
    except Exception as e:
        return f"[Σφάλμα κατά την ανάγνωση του αρχείου Excel: {e}]"


def read_supported_file(file_path: Path) -> str:
    suffix = file_path.suffix.lower()

    if suffix == ".txt":
        return read_text_file(file_path)

    if suffix == ".docx":
        return read_docx_file(file_path)

    if suffix == ".pdf":
        return read_pdf_file(file_path)

    if suffix in {".xlsx", ".xls"}:
        return read_excel_file(file_path)

    return ""


def limit_text(text: str, maximum_length: int) -> str:
    if len(text) <= maximum_length:
        return text

    return (
        text[:maximum_length]
        + "\n\n[The remaining file content was not sent due to the size limit.]"
    )


def read_module_file(filename: str) -> str:
    file_path = MODULE_DIR / filename

    if not file_path.exists():
        return ""

    return read_supported_file(file_path)


def read_reference_file(filename: str) -> str:
    file_path = REFERENCE_FILES_DIR / filename

    if not file_path.exists():
        return ""

    return read_supported_file(file_path)


def read_folder_reference_material(folder_path: Path) -> str:
    if not folder_path.exists():
        return ""

    sections = []

    for file_path in sorted(folder_path.rglob("*")):
        if not file_path.is_file():
            continue

        if file_path.suffix.lower() not in SUPPORTED_TEXT_EXTENSIONS:
            continue

        try:
            content = read_supported_file(file_path)
        except Exception as error:
            sections.append(
                f"\n--- FILE: {file_path.name} ---\n"
                f"[The file could not be read: {error}]"
            )
            continue

        if content:
            sections.append(
                f"\n--- REFERENCE FILE: {file_path.name} ---\n{content}"
            )

    return limit_text("\n".join(sections).strip(), MAX_REFERENCE_TEXT_LENGTH)


def read_uploaded_material(uploaded_file_paths: list[str]) -> str:
    sections = []

    for file_path_string in uploaded_file_paths:
        file_path = Path(file_path_string)

        if not file_path.exists():
            continue

        suffix = file_path.suffix.lower()

        if suffix not in SUPPORTED_TEXT_EXTENSIONS:
            continue

        try:
            content = read_supported_file(file_path)
        except Exception as error:
            sections.append(
                f"\n--- UPLOADED FILE: {file_path.name} ---\n"
                f"[The file could not be read: {error}]"
            )
            continue

        if content:
            sections.append(
                f"\n--- USER MATERIAL: {file_path.name} ---\n{content}"
            )

    return limit_text("\n".join(sections).strip(), MAX_FILE_TEXT_LENGTH)


def build_instructions() -> str:
    prompt = read_module_file("Instructions certificate teaching.txt")
    output_template = read_reference_file("output_template.txt")
    examples = read_folder_reference_material(EXAMPLES_DIR)
    reference_files = read_folder_reference_material(REFERENCE_FILES_DIR)

    instructions_sections = [
        "APPLICATION: Generation of Teaching Service Certificates",
        prompt,
    ]

    if output_template:
        instructions_sections.append(
            "\n## OUTPUT TEMPLATE\n"
            "Follow the output template below only as a structure.\n"
            "Do not include instructions, placeholders, or technical notes in the final output.\n\n"
            f"{output_template}"
        )

    if examples:
        instructions_sections.append(
            "\n## OUTPUT EXAMPLES\n"
            "The examples show the desired tone and quality level.\n"
            f"{examples}"
        )

    if reference_files:
        instructions_sections.append(
            "\n## SUPPORTING REFERENCE FILES\n"
            "Use these files only for finding missing data regarding assignments or programs. "
            f"{reference_files}"
        )

    return "\n\n".join(
        section for section in instructions_sections if section.strip()
    ).strip()


def build_user_input(
    input_method: str,
    production_mode: str,
    target_instructors: str,
    instructor_name: str,
    academic_year: str,
    semester: str,
    course: str,
    role: str,
    uploaded_material: str,
) -> str:
    
    prompt_lines = ["## USER PARAMETERS\n"]
    
    prompt_lines.append(f"Input Method: {'File extraction' if input_method == 'file' else 'Manual entry'}")
    prompt_lines.append(f"Production Mode: {'Single Certificate' if production_mode == 'single' else 'Mass Generation'}\n")

    if input_method == "file":
        if production_mode == "single":
            prompt_lines.append(f"Target Instructor (Extract ONLY for this person): {target_instructors}\n")
        elif production_mode == "mass":
            if target_instructors.strip().lower() == "all":
                prompt_lines.append("Target Instructors: ALL (Extract data and generate certificates for ALL instructors found in the uploaded file).\n")
            else:
                prompt_lines.append(f"Target Instructors (Extract ONLY for these specific persons): {target_instructors}\n")
            
        prompt_lines.append("## MATERIAL FOR EXTRACTION")
        prompt_lines.append(uploaded_material if uploaded_material else "[No readable text file was uploaded. Process cannot be completed.]")
    
    else:
        prompt_lines.append("## MANUAL INSTRUCTOR DATA")
        prompt_lines.append(f"Instructor Name: {instructor_name}")
        prompt_lines.append(f"Academic Year: {academic_year if academic_year else '[Not provided]'}")
        prompt_lines.append(f"Semester: {semester if semester else '[Not provided]'}")
        prompt_lines.append(f"Course: {course if course else '[Not provided]'}")
        prompt_lines.append(f"Role / Title: {role if role else '[Not provided]'}\n")

    prompt_lines.append("""
## TASK

Write the final certificate(s) of teaching service in Greek.
Strictly follow the user parameters and the output template.
Do not create details that are not supported by the input material.
If Mass generation is requested, output multiple certificates clearly separated.
Return only the final certificate document(s), ready for use.
""")

    return "\n".join(prompt_lines).strip()


def generate_certificate_teaching(
    input_method: str,
    production_mode: str,
    target_instructors: str,
    instructor_name: str,
    academic_year: str,
    semester: str,
    course: str,
    role: str,
    uploaded_file_paths: list[str],
) -> str:
    if not OPENAI_API_KEY:
        raise ValueError("OPENAI_API_KEY is not set in the .env file.")
    if not OPENAI_API_KEY.startswith("sk-"):
        raise ValueError("OPENAI_API_KEY in the .env file does not look valid.")

    try:
        OPENAI_API_KEY.encode("ascii")
    except UnicodeEncodeError:
        raise ValueError(
            "OPENAI_API_KEY contains non-ASCII characters. "
            "Please retype it in the .env file without smart quotes or hidden characters."
        )

    instructions = build_instructions()
    
    uploaded_material = ""
    if input_method == "file":
        uploaded_material = read_uploaded_material(uploaded_file_paths)

    user_input = build_user_input(
        input_method=input_method,
        production_mode=production_mode,
        target_instructors=target_instructors,
        instructor_name=instructor_name,
        academic_year=academic_year,
        semester=semester,
        course=course,
        role=role,
        uploaded_material=uploaded_material,
    )

    client = OpenAI(api_key=OPENAI_API_KEY)

    response = client.responses.create(
        model=OPENAI_MODEL,
        instructions=instructions,
        input=user_input,
    )

    return response.output_text.strip()