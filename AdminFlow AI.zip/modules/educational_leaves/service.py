from pathlib import Path

import pandas as pd
from docx import Document
from openai import OpenAI
from pypdf import PdfReader

from config import OPENAI_API_KEY, OPENAI_MODEL

MODULE_DIR = Path(__file__).resolve().parent
EXAMPLES_DIR = MODULE_DIR / "examples"
REFERENCE_FILES_DIR = MODULE_DIR / "reference_files"

MAX_FILE_TEXT_LENGTH = 30000
MAX_REFERENCE_TEXT_LENGTH = 50000

SUPPORTED_TEXT_EXTENSIONS = {".txt", ".docx", ".pdf", ".xls", ".xlsx"}

def read_text_file(file_path: Path) -> str:
    try:
        return file_path.read_text(encoding="utf-8").strip()
    except UnicodeDecodeError:
        return file_path.read_text(encoding="utf-8-sig").strip()

def read_docx_file(file_path: Path) -> str:
    document = Document(file_path)
    paragraphs = [
        paragraph.text.strip()
        for paragraph in document.paragraphs
        if paragraph.text.strip()
    ]
    table_rows = []
    for table in document.tables:
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            table_rows.append(" | ".join(cells))
    return "\n".join(paragraphs + table_rows).strip()

def read_pdf_file(file_path: Path) -> str:
    reader = PdfReader(str(file_path))
    pages_text = []
    for page in reader.pages:
        page_text = page.extract_text() or ""
        pages_text.append(page_text.strip())
    return "\n".join(pages_text).strip()

def read_excel_file(file_path: Path) -> str:
    try:
        df = pd.read_excel(file_path)
        return df.to_string(index=False)
    except Exception as e:
        return f"[Αδυναμία ανάγνωσης αρχείου Excel: {str(e)}]"

def read_supported_file(file_path: Path) -> str:
    suffix = file_path.suffix.lower()
    if suffix == ".txt":
        return read_text_file(file_path)
    if suffix == ".docx":
        return read_docx_file(file_path)
    if suffix == ".pdf":
        return read_pdf_file(file_path)
    if suffix in {".xls", ".xlsx"}:
        return read_excel_file(file_path)
    return ""

def limit_text(text: str, maximum_length: int) -> str:
    if len(text) <= maximum_length:
        return text
    return (
        text[:maximum_length]
        + "\n\n[Το υπόλοιπο περιεχόμενο του αρχείου παραλείφθηκε λόγω μεγέθους.]"
    )

def read_module_file(filename: str) -> str:
    file_path = MODULE_DIR / filename
    if not file_path.exists():
        return ""
    return read_supported_file(file_path)

def read_reference_file(filename: str) -> str:
    file_path = REFERENCE_FILES_DIR / filename
    if not file_path.exists():
        return ""
    return read_supported_file(file_path)

def read_category_reference_file(staff_category: str, filename: str) -> str:
    """
    Διαβάζει τα βοηθητικά αρχεία που βρίσκονται ΜΕΣΑ στον υποφάκελο της εκάστοτε κατηγορίας
    για την υλοποίηση του Query Routing (π.χ. reference_files/dep/regulations.txt).
    """
    # Προστασία Path Traversal (sanitization)
    safe_category = "".join(c for c in staff_category if c.isalnum() or c in ("_", "-"))
    if not safe_category:
        return ""
        
    file_path = REFERENCE_FILES_DIR / safe_category / filename
    if not file_path.exists():
        return ""
    return read_supported_file(file_path)

def read_example_file(filename: str) -> str:
    file_path = EXAMPLES_DIR / filename
    if not file_path.exists():
        return ""
    return read_supported_file(file_path)

def read_uploaded_material(uploaded_file_paths: list[str]) -> str:
    sections = []
    for file_path_string in uploaded_file_paths:
        file_path = Path(file_path_string)
        if not file_path.exists():
            continue
        suffix = file_path.suffix.lower()
        if suffix not in SUPPORTED_TEXT_EXTENSIONS:
            continue
        try:
            content = read_supported_file(file_path)
        except Exception as error:
            sections.append(
                f"\n--- UPLOADED FILE: {file_path.name} ---\n"
                f"[Το αρχείο δεν μπόρεσε να διαβαστεί: {error}]"
            )
            continue
        if content:
            sections.append(
                f"\n--- ΥΛΙΚΟ ΧΡΗΣΤΗ (ΦΑΚΕΛΟΣ ΔΙΚΑΙΟΛΟΓΗΤΙΚΩΝ): {file_path.name} ---\n{content}"
            )
    return limit_text("\n".join(sections).strip(), MAX_FILE_TEXT_LENGTH)

def build_instructions(staff_category: str) -> str:
    # 1. Βασικές Οδηγίες Μοντέλου
    prompt = read_module_file("Instructions_educational_leaves.txt")
    
    # 2. QUERY ROUTING: Φορτώνονται δυναμικά ΜΟΝΟ τα αρχεία της συγκεκριμένης κατηγορίας
    regulations = read_category_reference_file(staff_category, "regulations.txt")
    checklist = read_category_reference_file(staff_category, "checklist.txt")
    
    # 3. Κεντρικά Πρότυπα
    output_template = read_reference_file("output_template.txt")
    output_examples = read_example_file("output_examples.txt")

    instructions_sections = [
        "APPLICATION: Έλεγχος & Έκδοση Υπηρεσιακών Αδειών Προσωπικού",
        prompt,
    ]

    if regulations:
        instructions_sections.append(
            "\n## ΘΕΣΜΙΚΟ ΠΛΑΙΣΙΟ & ΚΑΝΟΝΕΣ (REGULATIONS)\n"
            f"{limit_text(regulations, MAX_REFERENCE_TEXT_LENGTH)}"
        )
        
    if checklist:
        instructions_sections.append(
            "\n## ΟΔΗΓΟΣ ΠΛΗΡΟΤΗΤΑΣ & ΔΙΚΑΙΟΛΟΓΗΤΙΚΑ (CHECKLIST)\n"
            f"{limit_text(checklist, MAX_REFERENCE_TEXT_LENGTH)}"
        )

    if output_template:
        instructions_sections.append(
            "\n## OUTPUT TEMPLATE (ΑΥΣΤΗΡΟ ΠΡΟΤΥΠΟ ΕΞΟΔΟΥ)\n"
            f"{limit_text(output_template, MAX_REFERENCE_TEXT_LENGTH)}"
        )

    if output_examples:
        instructions_sections.append(
            "\n## ΠΑΡΑΔΕΙΓΜΑΤΑ ΧΡΗΣΗΣ (FEW-SHOT EXAMPLES)\n"
            f"{limit_text(output_examples, MAX_REFERENCE_TEXT_LENGTH)}"
        )

    return "\n\n".join(
        section for section in instructions_sections if section.strip()
    ).strip()

def build_user_input(
    staff_category: str,
    leave_type: str,
    uploaded_material: str,
) -> str:
    return f"""
## ΠΑΡΑΜΕΤΡΟΙ ΧΡΗΣΤΗ (USER SETTINGS)

- Κατηγορία Προσωπικού: {staff_category if staff_category else "[Μη προσδιορισμένη]"}
- Αιτούμενος Τύπος Άδειας: {leave_type if leave_type else "[Μη προσδιορισμένος]"}

## ΥΛΙΚΟ ΠΡΟΣ ΑΝΑΛΥΣΗ (ΑΙΤΗΣΗ & ΔΙΚΑΙΟΛΟΓΗΤΙΚΑ)

{uploaded_material if uploaded_material else "[Δεν βρέθηκε υλικό προς ανάλυση.]"}

## ΕΡΓΑΣΙΑ (TASK)

Βάσει των δικαιολογητικών του χρήστη και των παραμέτρων που επιλέχθηκαν, έλεγξε την πληρότητα (με βάση το checklist.txt) και τη νομιμότητα (με βάση το regulations.txt) της αίτησης. 
Συνέταξε το Φύλλο Ελέγχου και τη Διοικητική Πράξη (ή την Πράξη Αναστολής / Απόρριψης αν υπάρχουν ελλείψεις) ακολουθώντας ΑΥΣΤΗΡΑ το Output Template. 
Μην επινοείς γεγονότα, αριθμούς πρωτοκόλλου, ημερομηνίες ή νομοθεσίες που δεν υπάρχουν ρητά στο κείμενο.
""".strip()

def generate_educational_leave_document(
    staff_category: str,
    leave_type: str,
    uploaded_file_paths: list[str],
) -> str:
    if not OPENAI_API_KEY:
        raise ValueError(
            "OPENAI_API_KEY is not set in the .env file."
            )
    if not OPENAI_API_KEY.startswith("sk-"):
        raise ValueError("OPENAI_API_KEY in the .env file does not look valid.")

    try:
        OPENAI_API_KEY.encode("ascii")
    except UnicodeEncodeError:
        raise ValueError(
            "OPENAI_API_KEY contains non-ASCII characters. "
            "Please retype it in the .env file without smart quotes or hidden characters."
        )

    instructions = build_instructions(staff_category)
    uploaded_material = read_uploaded_material(uploaded_file_paths)

    user_input = build_user_input(
        staff_category=staff_category,
        leave_type=leave_type,
        uploaded_material=uploaded_material,
    )

    client = OpenAI(api_key=OPENAI_API_KEY)

    response = client.responses.create(
        model=OPENAI_MODEL,
        instructions=instructions,
        input=user_input,
    )

    return response.output_text.strip()