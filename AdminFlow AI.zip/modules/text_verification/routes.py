from pathlib import Path
from uuid import uuid4

from flask import Blueprint, current_app, render_template, request, send_from_directory

from config import allowed_file, safe_filename
from modules.text_verification.service import generate_text_verification
from utils import cleanup_files

bp = Blueprint("text_verification", __name__)


@bp.route("/", methods=["GET", "POST"])
def text_verification():
    if request.method == "GET":
        return render_template("text-verification_form.html")

    text_type = request.form.get("text_type", "").strip()
    check_citations = request.form.get("check_citations", "yes").strip()
    strictness = request.form.get("strictness", "standard").strip()

    uploaded_file_paths = []
    uploaded_file_names = []
    skipped_file_names = []

    # Requires TEXT_VERIFICATION_UPLOAD_FOLDER to be set in config.py
    upload_folder = Path(current_app.config.get("TEXT_VERIFICATION_UPLOAD_FOLDER", current_app.config["UPLOAD_FOLDER"] + "/text-verification"))
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    for uploaded_file in request.files.getlist("files"):
        if not uploaded_file or not uploaded_file.filename:
            continue

        original_filename = safe_filename(uploaded_file.filename)

        if not allowed_file(original_filename):
            skipped_file_names.append(original_filename)
            continue

        unique_filename = f"{uuid4().hex}_{original_filename}"
        file_path = upload_folder / unique_filename

        uploaded_file.save(file_path)
        uploaded_file_paths.append(str(file_path))
        uploaded_file_names.append(original_filename)

    if not uploaded_file_paths:
        return render_template(
            "text-verification_form.html",
            error_message="You must upload the AI-generated text file for verification.",
            text_type=text_type,
            check_citations=check_citations,
            strictness=strictness,
            skipped_file_names=skipped_file_names,
        ), 400

    try:
        generated_report = generate_text_verification(
            text_type=text_type,
            check_citations=check_citations,
            strictness=strictness,
            uploaded_file_paths=uploaded_file_paths,
        )
    except ValueError as error:
        return render_template(
            "text-verification_form.html",
            error_message=str(error),
            text_type=text_type,
            check_citations=check_citations,
            strictness=strictness,
            skipped_file_names=skipped_file_names,
        ), 400
    except Exception as error:
        return render_template(
            "text-verification_form.html",
            error_message=(
                "A problem occurred while verifying the text. "
                f"Technical information: {error}"
            ),
            text_type=text_type,
            check_citations=check_citations,
            strictness=strictness,
            skipped_file_names=skipped_file_names,
        ), 500

    finally:
        # <--- ΠΡΟΣΘΗΚΗ: Καθαρίζει τα uploads αν υπήρξαν αρχεία
        if uploaded_file_paths:
            cleanup_files(uploaded_file_paths)

    output_filename = f"verification_report_{uuid4().hex}.txt"
    output_path = output_folder / output_filename
    output_path.write_text(generated_report, encoding="utf-8")

    return render_template(
        "text-verification_result.html",
        report=generated_report,
        output_filename=output_filename,
        text_type=text_type,
        check_citations=check_citations,
        strictness=strictness,
        uploaded_file_names=uploaded_file_names,
        skipped_file_names=skipped_file_names,
    )


@bp.route("/download/<output_filename>")
def download_report(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.startswith("verification_report_") or not output_filename.endswith(".txt"):
        return "File not found.", 404

    if not (output_folder / output_filename).exists():
        return "File not found.", 404

    return send_from_directory(
        output_folder,
        output_filename,
        as_attachment=True,
        download_name="fact_checking_report.txt",
    )