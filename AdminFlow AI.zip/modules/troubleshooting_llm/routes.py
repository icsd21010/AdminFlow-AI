import io
from pathlib import Path
from uuid import uuid4

from docx import Document
from flask import Blueprint, current_app, request, send_from_directory, send_file, jsonify

from config import allowed_file, safe_filename
from modules.troubleshooting_llm.service import generate_troubleshooting_response
from utils import cleanup_files

bp = Blueprint("troubleshooting_llm", __name__)

@bp.route("/", methods=["POST"])
def troubleshooting():
    # Το GET το αφαιρέσαμε, γιατί η φόρμα βρίσκεται ήδη στο home.html
    
    support_category = request.form.get("support_category", "").strip()
    user_query = request.form.get("user_query", "").strip()

    uploaded_file_paths = []
    uploaded_file_names = []
    skipped_file_names = []

    # Requires TROUBLESHOOTING_UPLOAD_FOLDER to be set in config.py
    upload_folder = Path(current_app.config.get("TROUBLESHOOTING_UPLOAD_FOLDER", current_app.config["UPLOAD_FOLDER"] + "/troubleshooting"))
    upload_folder.mkdir(parents=True, exist_ok=True)
    
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    for uploaded_file in request.files.getlist("files"):
        if not uploaded_file or not uploaded_file.filename:
            continue

        original_filename = safe_filename(uploaded_file.filename)

        if not allowed_file(original_filename) and not original_filename.lower().endswith('.log'):
            skipped_file_names.append(original_filename)
            continue

        unique_filename = f"{uuid4().hex}_{original_filename}"
        file_path = upload_folder / unique_filename

        uploaded_file.save(file_path)
        uploaded_file_paths.append(str(file_path))
        uploaded_file_names.append(original_filename)

    if not support_category:
        return jsonify({
            "success": False,
            "error_message": "Η επιλογή κατηγορίας υποστήριξης είναι υποχρεωτική."
        }), 400

    if not user_query and not uploaded_file_paths:
        return jsonify({
            "success": False,
            "error_message": "Πρέπει να γράψετε ένα ερώτημα ή να ανεβάσετε ένα αρχείο."
        }), 400

    try:
        generated_response = generate_troubleshooting_response(
            support_category=support_category,
            user_query=user_query,
            uploaded_file_paths=uploaded_file_paths,
        )
    except ValueError as error:
        return jsonify({
            "success": False,
            "error_message": str(error)
        }), 400
    except Exception as error:
        return jsonify({
            "success": False,
            "error_message": f"Προέκυψε σφάλμα κατά την ανάλυση: {error}"
        }), 500

    finally:
        # <--- ΠΡΟΣΘΗΚΗ: Καθαρίζει τα uploads αν υπήρξαν αρχεία
        if uploaded_file_paths:
            cleanup_files(uploaded_file_paths)

    output_filename = f"helpdesk_response_{uuid4().hex}.txt"
    output_path = output_folder / output_filename
    output_path.write_text(generated_response, encoding="utf-8")

    return jsonify({
        "success": True,
        "response": generated_response,
        "output_filename": output_filename,
        "uploaded_file_names": uploaded_file_names,
        "skipped_file_names": skipped_file_names
    })


@bp.route("/download/<output_filename>")
def download_response(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.endswith(".txt"):
        return "File not found.", 404

    if not (output_folder / output_filename).exists():
        return "File not found.", 404

    return send_from_directory(
        output_folder,
        output_filename,
        as_attachment=True,
        download_name="helpdesk_response.txt",
    )


@bp.route("/download_docx/<output_filename>")
def download_docx(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.endswith(".txt"):
        return "File not found.", 404

    file_path = output_folder / output_filename
    if not file_path.exists():
        return "File not found.", 404

    text_content = file_path.read_text(encoding="utf-8")

    doc = Document()
    for line in text_content.split('\n'):
        line_stripped = line.strip()
        if line_stripped.startswith('# '):
            doc.add_heading(line_stripped.replace('# ', ''), level=1)
        elif line_stripped.startswith('## '):
            doc.add_heading(line_stripped.replace('## ', ''), level=2)
        elif line_stripped.startswith('### '):
            doc.add_heading(line_stripped.replace('### ', ''), level=3)
        elif line_stripped:
            doc.add_paragraph(line_stripped)
        else:
            doc.add_paragraph("")

    file_stream = io.BytesIO()
    doc.save(file_stream)
    file_stream.seek(0)

    docx_filename = output_filename.replace('.txt', '.docx')
    return send_file(
        file_stream,
        as_attachment=True,
        download_name=docx_filename,
        mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    )