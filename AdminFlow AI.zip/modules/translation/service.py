from pathlib import Path
from zipfile import BadZipFile

from docx import Document
from openai import OpenAI
from pypdf import PdfReader

from config import OPENAI_API_KEY, OPENAI_MODEL


MODULE_DIR = Path(__file__).resolve().parent
EXAMPLES_DIR = MODULE_DIR / "examples"
REFERENCE_FILES_DIR = MODULE_DIR / "reference_files"

MAX_FILE_TEXT_LENGTH = 30000
MAX_REFERENCE_TEXT_LENGTH = 50000


def read_text_file(file_path: Path) -> str:
    try:
        return file_path.read_text(encoding="utf-8").strip()
    except UnicodeDecodeError:
        return file_path.read_text(encoding="utf-8-sig").strip()


def read_docx_file(file_path: Path) -> str:
    try:
        document = Document(file_path)
    except BadZipFile as error:
        raise ValueError(
            f"The file {file_path.name} is not a valid DOCX file or is corrupted: {error}"
        )

    sections = []

    for paragraph in document.paragraphs:
        text = paragraph.text.strip()
        if text:
            sections.append(text)

    for table in document.tables:
        table_lines = []
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            table_lines.append(" | ".join(cells))
        if table_lines:
            sections.append("\n".join(table_lines))

    return "\n".join(sections).strip()


def read_pdf_file(file_path: Path) -> str:
    reader = PdfReader(str(file_path))
    pages_text = []

    for page in reader.pages:
        page_text = page.extract_text() or ""
        pages_text.append(page_text.strip())

    return "\n".join(pages_text).strip()


def read_supported_file(file_path: Path) -> str:
    suffix = file_path.suffix.lower()

    if suffix == ".txt":
        return read_text_file(file_path)

    if suffix == ".docx":
        return read_docx_file(file_path)

    if suffix == ".pdf":
        return read_pdf_file(file_path)

    return ""


def limit_text(text: str, maximum_length: int) -> str:
    if len(text) <= maximum_length:
        return text

    return (
        text[:maximum_length]
        + "\n\n[The remaining file content was not sent due to the size limit.]"
    )


def read_module_file(filename: str) -> str:
    file_path = MODULE_DIR / filename
    if not file_path.exists():
        return ""
    return read_supported_file(file_path)


def read_folder_reference_material(folder_path: Path) -> str:
    if not folder_path.exists():
        return ""

    sections = []

    for file_path in sorted(folder_path.rglob("*")):
        if not file_path.is_file():
            continue

        if file_path.suffix.lower() not in {".txt", ".docx", ".pdf"}:
            continue

        try:
            content = read_supported_file(file_path)
        except Exception as error:
            sections.append(
                f"\n--- FILE: {file_path.name} ---\n"
                f"[The file could not be read: {error}]"
            )
            continue

        if content:
            sections.append(f"\n--- REFERENCE FILE: {file_path.name} ---\n{content}")

    return limit_text("\n".join(sections).strip(), MAX_REFERENCE_TEXT_LENGTH)


def read_uploaded_material(uploaded_file_paths: list[str]) -> str:
    sections = []

    for file_path_string in uploaded_file_paths:
        file_path = Path(file_path_string)

        if not file_path.exists():
            continue

        suffix = file_path.suffix.lower()

        try:
            if suffix == ".txt":
                content = read_text_file(file_path)
            elif suffix == ".docx":
                content = read_docx_file(file_path)
            elif suffix == ".pdf":
                content = read_pdf_file(file_path)
            else:
                sections.append(
                    f"\n--- UPLOADED FILE: {file_path.name} ---\n"
                    "[The file was saved, but text extraction is not yet available for this file type.]"
                )
                continue
        except Exception as error:
            sections.append(
                f"\n--- UPLOADED FILE: {file_path.name} ---\n"
                f"[The file could not be read: {error}]"
            )
            continue

        if content:
            sections.append(f"\n--- USER MATERIAL: {file_path.name} ---\n{content}")

    return limit_text("\n".join(sections).strip(), MAX_FILE_TEXT_LENGTH)


def build_instructions() -> str:
    prompt = read_module_file("Instructions translation.txt")
    output_template = read_module_file("output_template.txt")
    style_guide = read_module_file("style_guide.txt")
    examples = read_folder_reference_material(EXAMPLES_DIR)
    reference_files = read_folder_reference_material(REFERENCE_FILES_DIR)

    glossar_path = MODULE_DIR / "glossar.docx"
    glossar = ""
    if glossar_path.exists():
        try:
            glossar = read_docx_file(glossar_path)
        except ValueError:
            glossar = ""

    instructions_sections = [
        "APPLICATION: Translation of Various Text Types",
        prompt,
    ]

    if glossar:
        instructions_sections.append(
            "\n## GLOSSARY\n"
            "Use the glossary below as a binding terminology reference where required.\n"
            f"{glossar}"
        )

    if output_template:
        instructions_sections.append("\n## OUTPUT TEMPLATE\n" + output_template)

    if style_guide:
        instructions_sections.append("\n## STYLE GUIDE\n" + style_guide)

    if examples:
        instructions_sections.append("\n## OUTPUT EXAMPLES\n" + examples)

    if reference_files:
        instructions_sections.append("\n## SUPPORTING REFERENCE FILES\n" + reference_files)

    return "\n\n".join(section for section in instructions_sections if section.strip()).strip()


def map_style_profile(style_profile: str) -> str:
    mapping = {
        "Αυστηρό": "STRICT_LEGAL",
        "Επίσημο": "FORMAL",
        "Θεσμικό": "INSTITUTIONAL",
        "Καθημερινής επικοινωνίας": "EVERYDAY_COMMUNICATION",
        "Επικοινωνιακό": "PR_PUBLIC",
        "Ακαδημαϊκό": "ACADEMIC",
    }
    return mapping.get(style_profile, style_profile)


def build_user_input(
    target_language: str,
    use_glossar: str,
    style_profile: str,
    notes: str,
    uploaded_material: str,
) -> str:
    use_glossar_choice = "Yes" if use_glossar == "yes" else "No"
    technical_style_profile = map_style_profile(style_profile)

    return f"""
## USER PARAMETERS


Target language: {target_language}
Use glossary: {use_glossar_choice}
Style profile: {style_profile}
Internal style code: {technical_style_profile}


## ADDITIONAL USER INSTRUCTIONS


{notes if notes else "[No additional instructions were provided.]"}


## MATERIAL FOR TRANSLATION


{uploaded_material if uploaded_material else "[No readable text file was uploaded. Use only the form parameters and ask for clarification only if absolutely necessary.]"}


## TASK


Translate the text into the target language.
Strictly follow the selected style and glossary.
Preserve the meaning, structure, and critical details of the original.
Return only the final translated text.
""".strip()


def generate_translation(
    target_language: str,
    use_glossar: str,
    style_profile: str,
    notes: str,
    uploaded_file_paths: list[str],
) -> str:
    if not OPENAI_API_KEY:
        raise ValueError("OPENAI_API_KEY is not set in the .env file.")

    instructions = build_instructions()
    uploaded_material = read_uploaded_material(uploaded_file_paths)

    user_input = build_user_input(
        target_language=target_language,
        use_glossar=use_glossar,
        style_profile=style_profile,
        notes=notes,
        uploaded_material=uploaded_material,
    )

    client = OpenAI(api_key=OPENAI_API_KEY)
    response = client.responses.create(
        model=OPENAI_MODEL,
        instructions=instructions,
        input=user_input,
    )
    return response.output_text.strip()