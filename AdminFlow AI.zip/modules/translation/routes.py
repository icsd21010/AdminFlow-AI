import io
from pathlib import Path
from uuid import uuid4

from docx import Document
from flask import Blueprint, current_app, render_template, request, send_from_directory, send_file

from config import allowed_file, safe_filename
from modules.translation.service import generate_translation
from utils import cleanup_files

bp = Blueprint("translation", __name__)

@bp.route("/", methods=["GET", "POST"])
def translation():
    if request.method == "GET":
        return render_template("translation_form.html")

    target_language = request.form.get("target_language", "").strip()
    use_glossar = request.form.get("use_glossar", "").strip()
    style_profile = request.form.get("style_profile", "").strip()
    notes = request.form.get("notes", "").strip()

    uploaded_file_paths = []
    uploaded_file_names = []
    skipped_file_names = []

    upload_folder = Path(current_app.config["TRANSLATION_UPLOAD_FOLDER"])
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    for uploaded_file in request.files.getlist("files"):
        if not uploaded_file or not uploaded_file.filename:
            continue

        original_filename = safe_filename(uploaded_file.filename)

        if not allowed_file(original_filename):
            skipped_file_names.append(original_filename)
            continue

        unique_filename = f"{uuid4().hex}_{original_filename}"
        file_path = upload_folder / unique_filename

        uploaded_file.save(file_path)
        uploaded_file_paths.append(str(file_path))
        uploaded_file_names.append(original_filename)

    try:
        generated_translation = generate_translation(
            target_language=target_language,
            use_glossar=use_glossar,
            style_profile=style_profile,
            notes=notes,
            uploaded_file_paths=uploaded_file_paths,
        )
    except ValueError as error:
        return render_template(
            "translation_form.html",
            error_message=str(error),
            target_language=target_language,
            use_glossar=use_glossar,
            style_profile=style_profile,
            notes=notes,
        ), 400
    except Exception as error:
        return render_template(
            "translation_form.html",
            error_message=(
                "A problem occurred while generating the translation. "
                f"Technical information: {error}"
            ),
            target_language=target_language,
            use_glossar=use_glossar,
            style_profile=style_profile,
            notes=notes,
        ), 500

    finally:
        # <--- ΠΡΟΣΘΗΚΗ: Καθαρίζει τα uploads αν υπήρξαν αρχεία
        if uploaded_file_paths:
            cleanup_files(uploaded_file_paths)

    output_filename = f"translation_{uuid4().hex}.txt"
    output_path = output_folder / output_filename
    output_path.write_text(generated_translation, encoding="utf-8")

    return render_template(
        "translation_result.html",
        translation=generated_translation,
        output_filename=output_filename,
        target_language=target_language,
        use_glossar=use_glossar,
        style_profile=style_profile,
        notes=notes,
        uploaded_file_names=uploaded_file_names,
        skipped_file_names=skipped_file_names,
    )


@bp.route("/download/<output_filename>")
def download_translation(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.endswith(".txt"):
        return "File not found.", 404

    if not (output_folder / output_filename).exists():
        return "File not found.", 404

    return send_from_directory(
        output_folder,
        output_filename,
        as_attachment=True,
        download_name="translation.txt",
    )


@bp.route("/download_docx/<output_filename>")
def download_docx(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.endswith(".txt"):
        return "File not found.", 404

    file_path = output_folder / output_filename
    if not file_path.exists():
        return "File not found.", 404

    text_content = file_path.read_text(encoding="utf-8")

    doc = Document()
    for line in text_content.split('\n'):
        line_stripped = line.strip()
        if line_stripped.startswith('# '):
            doc.add_heading(line_stripped.replace('# ', ''), level=1)
        elif line_stripped.startswith('## '):
            doc.add_heading(line_stripped.replace('## ', ''), level=2)
        elif line_stripped.startswith('### '):
            doc.add_heading(line_stripped.replace('### ', ''), level=3)
        elif line_stripped:
            doc.add_paragraph(line_stripped)
        else:
            doc.add_paragraph("")

    file_stream = io.BytesIO()
    doc.save(file_stream)
    file_stream.seek(0)

    docx_filename = output_filename.replace('.txt', '.docx')
    return send_file(
        file_stream,
        as_attachment=True,
        download_name=docx_filename,
        mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    )