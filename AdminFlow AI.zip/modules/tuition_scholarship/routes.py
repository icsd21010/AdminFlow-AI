from pathlib import Path
from uuid import uuid4

from flask import Blueprint, current_app, render_template, request, send_from_directory

from config import allowed_file, safe_filename
from modules.tuition_scholarship.service import generate_tuition_scholarship_report
from utils import cleanup_files

bp = Blueprint("tuition_scholarship", __name__)


@bp.route("/", methods=["GET", "POST"])
def tuition_scholarship():
    if request.method == "GET":
        return render_template("tuition_scholarship_form.html")

    request_type = request.form.get("request_type", "").strip()
    deadline = request.form.get("deadline", "").strip()

    uploaded_file_paths = []
    uploaded_file_names = []
    skipped_file_names = []

    # Δημιουργία φακέλου δυναμικά (αν δεν έχει προστεθεί στο config.py)
    upload_folder = Path(current_app.config.get(
        "TUITION_SCHOLARSHIP_UPLOAD_FOLDER", 
        current_app.config["UPLOAD_FOLDER"] + "/tuition-scholarship"
    ))
    upload_folder.mkdir(parents=True, exist_ok=True)
    
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    for uploaded_file in request.files.getlist("files"):
        if not uploaded_file or not uploaded_file.filename:
            continue

        original_filename = safe_filename(uploaded_file.filename)

        if not allowed_file(original_filename):
            skipped_file_names.append(original_filename)
            continue

        unique_filename = f"{uuid4().hex}_{original_filename}"
        file_path = upload_folder / unique_filename

        uploaded_file.save(file_path)
        uploaded_file_paths.append(str(file_path))
        uploaded_file_names.append(original_filename)

    if not request_type:
        return render_template(
            "tuition_scholarship_form.html",
            error_message="Πρέπει να επιλέξετε τον Τύπο Αίτησης.",
            request_type=request_type,
            deadline=deadline,
            skipped_file_names=skipped_file_names,
        ), 400

    if not uploaded_file_paths:
        return render_template(
            "tuition_scholarship_form.html",
            error_message="Πρέπει να μεταφορτώσετε την αίτηση, τα δικαιολογητικά και (εφόσον πρόκειται για υποτροφία) την προκήρυξη.",
            request_type=request_type,
            deadline=deadline,
            skipped_file_names=skipped_file_names,
        ), 400

    try:
        generated_report = generate_tuition_scholarship_report(
            request_type=request_type,
            deadline=deadline,
            uploaded_file_paths=uploaded_file_paths,
        )
    except ValueError as error:
        return render_template(
            "tuition_scholarship_form.html",
            error_message=str(error),
            request_type=request_type,
            deadline=deadline,
            skipped_file_names=skipped_file_names,
        ), 400
    except Exception as error:
        return render_template(
            "tuition_scholarship_form.html",
            error_message=(
                "Παρουσιάστηκε πρόβλημα κατά τον έλεγχο της αίτησης. "
                f"Τεχνικές πληροφορίες: {error}"
            ),
            request_type=request_type,
            deadline=deadline,
            skipped_file_names=skipped_file_names,
        ), 500

    finally:
        # <--- ΠΡΟΣΘΗΚΗ: Καθαρίζει τα uploads αν υπήρξαν αρχεία
        if uploaded_file_paths:
            cleanup_files(uploaded_file_paths)

    output_filename = f"tuition_scholarship_report_{uuid4().hex}.txt"
    output_path = output_folder / output_filename
    output_path.write_text(generated_report, encoding="utf-8")

    return render_template(
        "tuition_scholarship_result.html",
        report=generated_report,
        output_filename=output_filename,
        request_type=request_type,
        deadline=deadline,
        uploaded_file_names=uploaded_file_names,
        skipped_file_names=skipped_file_names,
    )


@bp.route("/download/<output_filename>")
def download_report(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.startswith("tuition_scholarship_report_") or not output_filename.endswith(".txt"):
        return "File not found.", 404

    if not (output_folder / output_filename).exists():
        return "File not found.", 404

    return send_from_directory(
        output_folder,
        output_filename,
        as_attachment=True,
        download_name="application_check_report.txt",
    )