import logging
import time
from pathlib import Path
from zipfile import BadZipFile

from docx import Document
from openai import OpenAI
from pypdf import PdfReader

from config import (
    MINUTES_TRANSCRIPTS_FOLDER,
    OPENAI_API_KEY,
    OPENAI_MODEL,
)
from modules.minutes.transcription import (
    TranscriptionError,
    transcribe_audio_file,
)
from modules.minutes.transcript_store import save_transcript


logger = logging.getLogger("ai_process_accelerator")

MODULE_DIR = Path(__file__).resolve().parent
EXAMPLES_DIR = MODULE_DIR / "examples"
REFERENCE_FILES_DIR = MODULE_DIR / "reference_files"

TEXT_FILE_EXTENSIONS = {".txt", ".docx", ".pdf"}
AUDIO_FILE_EXTENSIONS = {
    ".mp3",
    ".wav",
    ".ogg",
    ".m4a",
    ".aac",
    ".flac",
}

MAX_FILE_TEXT_LENGTH = 30000
MAX_REFERENCE_TEXT_LENGTH = 50000


def read_text_file(file_path: Path) -> str:
    try:
        return file_path.read_text(encoding="utf-8").strip()
    except UnicodeDecodeError:
        return file_path.read_text(encoding="utf-8-sig").strip()


def read_docx_file(file_path: Path) -> str:
    try:
        document = Document(file_path)
    except BadZipFile as error:
        raise ValueError(
            f"The file {file_path.name} is not a valid DOCX file: {error}"
        )

    sections = []

    for paragraph in document.paragraphs:
        text = paragraph.text.strip()

        if text:
            sections.append(text)

    for table in document.tables:
        table_rows = []

        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            table_rows.append(" | ".join(cells))

        if table_rows:
            sections.append("\n".join(table_rows))

    return "\n".join(sections).strip()


def read_pdf_file(file_path: Path) -> str:
    reader = PdfReader(str(file_path))
    pages_text = []

    for page in reader.pages:
        page_text = page.extract_text() or ""
        pages_text.append(page_text.strip())

    return "\n".join(pages_text).strip()


def read_supported_text_file(file_path: Path) -> str:
    suffix = file_path.suffix.lower()

    if suffix == ".txt":
        return read_text_file(file_path)

    if suffix == ".docx":
        return read_docx_file(file_path)

    if suffix == ".pdf":
        return read_pdf_file(file_path)

    return ""


def limit_text(text: str, maximum_length: int) -> str:
    if len(text) <= maximum_length:
        return text

    logger.warning(
        "Text material truncated due to limit | original_characters=%s | "
        "maximum_characters=%s",
        len(text),
        maximum_length,
    )

    return (
        text[:maximum_length]
        + "\n\n[The remaining content was not included due to the size limit.]"
    )


def read_module_file(filename: str) -> str:
    file_path = MODULE_DIR / filename

    if not file_path.exists():
        logger.warning("Module instructions file not found")
        return ""

    content = read_supported_text_file(file_path)

    logger.info(
        "Module instructions file read | characters=%s",
        len(content),
    )

    return content


def read_folder_reference_material(folder_path: Path) -> str:
    if not folder_path.exists():
        logger.warning(
            "Reference material folder not found | folder=%s",
            folder_path.name,
        )
        return ""

    sections = []
    files_read = 0
    files_failed = 0

    for file_path in sorted(folder_path.rglob("*")):
        if not file_path.is_file():
            continue

        if file_path.suffix.lower() not in TEXT_FILE_EXTENSIONS:
            continue

        try:
            content = read_supported_text_file(file_path)
        except Exception as error:
            files_failed += 1
            logger.warning(
                "Could not read reference file | extension=%s | "
                "error_type=%s",
                file_path.suffix.lower(),
                type(error).__name__,
            )
            sections.append(
                f"\n--- REFERENCE FILE: {file_path.name} ---\n"
                f"[Could not be read: {error}]"
            )
            continue

        if content:
            files_read += 1
            sections.append(
                f"\n--- REFERENCE FILE: {file_path.name} ---\n{content}"
            )

    collected_text = "\n".join(sections).strip()
    limited_text = limit_text(collected_text, MAX_REFERENCE_TEXT_LENGTH)

    logger.info(
        "Reference material read | folder=%s | files_read=%s | "
        "files_failed=%s | characters=%s",
        folder_path.name,
        files_read,
        files_failed,
        len(limited_text),
    )

    return limited_text


def transcribe_audio_locally(file_path: Path) -> str:
    """Performs local speech-to-text and saves the transcript."""
    logger.info(
        "Local transcription started from service | extension=%s",
        file_path.suffix.lower(),
    )

    try:
        result = transcribe_audio_file(file_path)
    except TranscriptionError as error:
        logger.warning(
            "Local transcription failed from service | extension=%s",
            file_path.suffix.lower(),
        )
        raise ValueError(
            f'Local transcription failed for file '
            f'"{file_path.name}": {error}'
        ) from error

    transcript_text = result["text"]

    transcript_path, metadata_path = save_transcript(
        transcript_text=transcript_text,
        source_filename=file_path.name,
        transcripts_folder=MINUTES_TRANSCRIPTS_FOLDER,
        metadata={
            "transcription_model": result["model"],
            "language": result["language"],
            "segment_count": len(result["chunks"]),
        },
    )

    logger.info(
        "Local transcript saved | transcript_file=%s | "
        "metadata_file=%s | transcript_characters=%s | segments=%s",
        transcript_path.name,
        metadata_path.name,
        len(transcript_text),
        len(result["chunks"]),
    )

    return transcript_text


def read_uploaded_material(uploaded_file_paths: list[str]) -> str:
    sections = []
    processed_files = 0
    failed_files = 0

    for file_path_string in uploaded_file_paths:
        file_path = Path(file_path_string)

        if not file_path.exists():
            failed_files += 1
            logger.warning(
                "Uploaded file not found during processing | extension=%s",
                file_path.suffix.lower() or "unknown",
            )
            continue

        suffix = file_path.suffix.lower()

        try:
            if suffix in TEXT_FILE_EXTENSIONS:
                logger.info(
                    "Processing uploaded text file | extension=%s",
                    suffix,
                )
                content = read_supported_text_file(file_path)
                material_label = "USER TEXT MATERIAL"

            elif suffix in AUDIO_FILE_EXTENSIONS:
                content = transcribe_audio_locally(file_path)
                material_label = "LOCAL AUDIO FILE TRANSCRIPTION"

            else:
                failed_files += 1
                logger.warning(
                    "Unsupported uploaded file | extension=%s",
                    suffix or "unknown",
                )
                sections.append(
                    f"\n--- USER FILE: {file_path.name} ---\n"
                    "[This file type is not supported.]"
                )
                continue

        except Exception as error:
            failed_files += 1
            logger.warning(
                "Uploaded file processing failed | extension=%s | "
                "error_type=%s",
                suffix or "unknown",
                type(error).__name__,
            )
            sections.append(
                f"\n--- USER FILE: {file_path.name} ---\n"
                f"[The file could not be processed: {error}]"
            )
            continue

        if content:
            processed_files += 1
            sections.append(
                f"\n--- {material_label}: {file_path.name} ---\n{content}"
            )

    collected_text = "\n".join(sections).strip()
    limited_text = limit_text(collected_text, MAX_FILE_TEXT_LENGTH)

    logger.info(
        "Uploaded material processing completed | uploaded_files=%s | "
        "processed_files=%s | failed_files=%s | characters=%s",
        len(uploaded_file_paths),
        processed_files,
        failed_files,
        len(limited_text),
    )

    return limited_text


def build_instructions() -> str:
    instructions = read_module_file("Instructions minutes.txt")
    examples = read_folder_reference_material(EXAMPLES_DIR)
    reference_files = read_folder_reference_material(REFERENCE_FILES_DIR)

    sections = [
        "APPLICATION: Creating meeting minutes from a recording",
        instructions,
    ]

    if reference_files:
        sections.append(
            "\n## TEMPLATES AND SUPPORTING FILES\n"
            "Use the following only as a template for formatting, "
            "institutional language, and structure. Do not transfer unrelated "
            "facts or details from them into the new minutes.\n"
            f"{reference_files}"
        )

    if examples:
        sections.append(
            "\n## OUTPUT EXAMPLES\n"
            "The examples show the expected quality, "
            "structure, and style. They are not a source of factual details "
            "for the new meeting.\n"
            f"{examples}"
        )

    combined_instructions = "\n\n".join(
        section for section in sections if section.strip()
    ).strip()

    logger.info(
        "Minutes instructions prepared | characters=%s | "
        "has_primary_instructions=%s | has_examples=%s | "
        "has_reference_material=%s",
        len(combined_instructions),
        bool(instructions),
        bool(examples),
        bool(reference_files),
    )

    return combined_instructions


def build_user_input(
    meeting_body: str,
    minutes_number: str,
    decision_or_topic: str,
    institution_name: str,
    members_list: str,
    uploaded_material: str,
) -> str:
    return f"""
## MEETING DETAILS


Meeting body: {meeting_body}
Minutes number: {minutes_number}
Topic or decision: {decision_or_topic}
University or institution: {institution_name}
List of members:
{members_list if members_list else "[No members list was provided.]"}


## MATERIAL SOURCES


{uploaded_material if uploaded_material else "[No readable material could be extracted from the submitted files.]"}


## TASK


Draft complete meeting minutes in Greek.


Use only the details that are supported by the
form data and the submitted material. Do not invent names,
dates, times, decisions, votes, numbers, or participants.


If a critical detail cannot be established with certainty, note it in the
"Remarks / Points to Confirm" section, as defined by the
model instructions.


Return only the final minutes, ready for review by the Secretariat.
""".strip()


def generate_minutes(
    meeting_body: str,
    minutes_number: str,
    decision_or_topic: str,
    institution_name: str,
    members_list: str,
    uploaded_file_paths: list[str],
) -> str:
    request_started_at = time.perf_counter()

    logger.info(
        "Minutes generation started | uploaded_files=%s | "
        "has_members_list=%s",
        len(uploaded_file_paths),
        bool(members_list),
    )

    if not OPENAI_API_KEY:
        logger.error("OPENAI_API_KEY not found for minutes generation")
        raise ValueError("OPENAI_API_KEY is not set in the .env file.")

    uploaded_material = read_uploaded_material(uploaded_file_paths)

    if not uploaded_material:
        logger.error(
            "No readable uploaded material available for minutes generation"
        )
        raise ValueError(
            "None of the submitted files could be read or locally transcribed."
        )

    instructions = build_instructions()

    user_input = build_user_input(
        meeting_body=meeting_body,
        minutes_number=minutes_number,
        decision_or_topic=decision_or_topic,
        institution_name=institution_name,
        members_list=members_list,
        uploaded_material=uploaded_material,
    )

    logger.info(
        "OpenAI minutes generation started | model=%s | "
        "instructions_characters=%s | input_characters=%s",
        OPENAI_MODEL,
        len(instructions),
        len(user_input),
    )

    try:
        client = OpenAI(api_key=OPENAI_API_KEY)

        response = client.responses.create(
            model=OPENAI_MODEL,
            instructions=instructions,
            input=user_input,
        )

        generated_minutes = response.output_text.strip()

    except Exception as error:
        logger.exception(
            "OpenAI minutes generation failed | model=%s | error_type=%s",
            OPENAI_MODEL,
            type(error).__name__,
        )
        raise ValueError(
            "A problem occurred while drafting the minutes."
        ) from error

    if not generated_minutes:
        logger.error(
            "OpenAI model returned empty minutes | model=%s",
            OPENAI_MODEL,
        )
        raise ValueError(
            "The model did not return any minutes text."
        )

    elapsed_seconds = time.perf_counter() - request_started_at

    logger.info(
        "Minutes generation completed | model=%s | seconds=%.2f | "
        "output_characters=%s",
        OPENAI_MODEL,
        elapsed_seconds,
        len(generated_minutes),
    )

    return generated_minutes