from __future__ import annotations

from datetime import datetime
from pathlib import Path
import json
import re
from typing import Any


def _safe_stem(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9Α-Ωα-ω_-]+", "_", value)
    cleaned = cleaned.strip("._-")
    return cleaned or "minutes_transcript"


def save_transcript(
    transcript_text: str,
    source_filename: str,
    transcripts_folder: Path,
    metadata: dict[str, Any] | None = None,
) -> tuple[Path, Path]:
    transcripts_folder.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_name = _safe_stem(Path(source_filename).stem)
    base_name = f"{safe_name}_{timestamp}"

    transcript_path = transcripts_folder / f"{base_name}.txt"
    metadata_path = transcripts_folder / f"{base_name}.json"

    transcript_path.write_text(transcript_text.strip(), encoding="utf-8")

    saved_metadata = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "source_filename": Path(source_filename).name,
        "transcript_filename": transcript_path.name,
        "character_count": len(transcript_text),
    }

    if metadata:
        saved_metadata.update(metadata)

    metadata_path.write_text(
        json.dumps(saved_metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    return transcript_path, metadata_path