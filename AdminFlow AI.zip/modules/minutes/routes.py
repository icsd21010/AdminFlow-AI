import logging
from pathlib import Path
from uuid import uuid4

from flask import (
    Blueprint,
    current_app,
    render_template,
    request,
    send_from_directory,
)

from config import safe_filename
from modules.minutes.service import generate_minutes
from utils import cleanup_files

logger = logging.getLogger("ai_process_accelerator")

bp = Blueprint("minutes", __name__)


@bp.before_request
def disable_max_content_length():
    """
    Αφαιρεί το όριο 16MB (MAX_CONTENT_LENGTH) ΑΠΟΚΛΕΙΣΤΙΚΑ για τη
    συγκεκριμένη διεργασία (Minutes), επιτρέποντας μεγάλα αρχεία ήχου.
    """
    request.max_content_length = None


ALLOWED_MINUTES_EXTENSIONS = {
    "txt",
    "docx",
    "pdf",
    "mp3",
    "wav",
    "ogg",
    "m4a",
    "aac",
    "flac",
}


def is_allowed_minutes_file(filename: str) -> bool:
    if "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    return ext in ALLOWED_MINUTES_EXTENSIONS


@bp.route("/", methods=["GET", "POST"])
def minutes():
    if request.method == "GET":
        logger.info("Minutes form view")
        return render_template("minutes_form.html")

    logger.info(
        "Minutes generation request received | uploaded_request_files=%s",
        len(request.files.getlist("files")),
    )

    meeting_body = request.form.get("meeting_body", "").strip()
    minutes_number = request.form.get("minutes_number", "").strip()
    decision_or_topic = request.form.get("decision_or_topic", "").strip()
    institution_name = request.form.get("institution_name", "").strip()
    members_list = request.form.get("members_list", "").strip()

    uploaded_file_paths = []
    uploaded_file_names = []
    skipped_file_names = []

    upload_folder = Path(current_app.config["MINUTES_UPLOAD_FOLDER"])
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    for uploaded_file in request.files.getlist("files"):
        if not uploaded_file or not uploaded_file.filename:
            continue

        original_filename = safe_filename(uploaded_file.filename)

        if not is_allowed_minutes_file(original_filename):
            skipped_file_names.append(original_filename)
            logger.warning(
                "Skipping unsupported uploaded file | extension=%s",
                Path(original_filename).suffix.lower() or "unknown",
            )
            continue

        unique_filename = f"{uuid4().hex}_{original_filename}"
        file_path = upload_folder / unique_filename

        uploaded_file.save(file_path)
        uploaded_file_paths.append(str(file_path))
        uploaded_file_names.append(original_filename)

        logger.info(
            "Uploaded file saved | extension=%s",
            Path(original_filename).suffix.lower(),
        )

    form_data = {
        "meeting_body": meeting_body,
        "minutes_number": minutes_number,
        "decision_or_topic": decision_or_topic,
        "institution_name": institution_name,
        "members_list": members_list,
    }

    required_fields = {
        "meeting_body": "Meeting body",
        "minutes_number": "Minutes number",
        "decision_or_topic": "Decision or topic",
        "institution_name": "University or institution",
    }

    for field_name, field_label in required_fields.items():
        if not form_data[field_name]:
            logger.warning(
                "Minutes form rejected due to required field | field=%s",
                field_name,
            )
            if uploaded_file_paths:
                cleanup_files(uploaded_file_paths)

            return render_template(
                "minutes_form.html",
                error_message=f'The "{field_label}" field is required.',
                skipped_file_names=skipped_file_names,
                **form_data,
            ), 400

    if not uploaded_file_paths:
        logger.warning(
            "Minutes form rejected without valid uploaded file | "
            "skipped_files=%s",
            len(skipped_file_names),
        )
        return render_template(
            "minutes_form.html",
            error_message=(
                "Please upload at least one allowed audio or text file."
            ),
            skipped_file_names=skipped_file_names,
            **form_data,
        ), 400

    try:
        generated_minutes = generate_minutes(
            meeting_body=meeting_body,
            minutes_number=minutes_number,
            decision_or_topic=decision_or_topic,
            institution_name=institution_name,
            members_list=members_list,
            uploaded_file_paths=uploaded_file_paths,
        )

    except ValueError as error:
        logger.warning(
            "Minutes generation failed with controlled error"
        )
        return render_template(
            "minutes_form.html",
            error_message=str(error),
            skipped_file_names=skipped_file_names,
            **form_data,
        ), 400

    except Exception as error:
        logger.exception(
            "Unexpected minutes generation failure | error_type=%s",
            type(error).__name__,
        )
        return render_template(
            "minutes_form.html",
            error_message=(
                "A problem occurred while generating the minutes. "
                "Please try again later."
            ),
            skipped_file_names=skipped_file_names,
            **form_data,
        ), 500

    finally:
        if uploaded_file_paths:
            cleanup_files(uploaded_file_paths)

    output_filename = f"praktiko_{uuid4().hex}.txt"
    output_path = output_folder / output_filename
    output_path.write_text(generated_minutes, encoding="utf-8")

    logger.info(
        "Minutes request completed | output_characters=%s | "
        "uploaded_files=%s | skipped_files=%s",
        len(generated_minutes),
        len(uploaded_file_names),
        len(skipped_file_names),
    )

    return render_template(
        "minutes_result.html",
        minutes=generated_minutes,
        output_filename=output_filename,
        uploaded_file_names=uploaded_file_names,
        skipped_file_names=skipped_file_names,
        **form_data,
    )


@bp.route("/download/<output_filename>")
def download_minutes(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.startswith("praktiko_") or not output_filename.endswith(
        ".txt"
    ):
        logger.warning("Invalid minutes download attempt")
        return "File not found.", 404

    if not (output_folder / output_filename).exists():
        logger.warning("Requested minutes file was not found")
        return "File not found.", 404

    logger.info("Generated minutes download")

    return send_from_directory(
        output_folder,
        output_filename,
        as_attachment=True,
        download_name="meeting_minutes.txt",
    )