from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any

import whisper


logger = logging.getLogger("ai_process_accelerator")

MODEL_NAME = "small"
DEVICE = "cpu"

_whisper_model = None


class TranscriptionError(Exception):
    """Error during local transcription."""


def get_transcription_model():
    """
    Loads the Whisper small model locally on CPU only once.
    """
    global _whisper_model

    if _whisper_model is not None:
        logger.info(
            "Using already loaded Whisper model | model=%s | device=%s",
            MODEL_NAME,
            DEVICE,
        )
        return _whisper_model

    started_at = time.perf_counter()

    try:
        logger.info(
            "Whisper model loading started | model=%s | device=%s",
            MODEL_NAME,
            DEVICE,
        )

        _whisper_model = whisper.load_model(
            MODEL_NAME,
            device=DEVICE,
        )

        elapsed_seconds = time.perf_counter() - started_at

        logger.info(
            "Whisper model loading completed | model=%s | seconds=%.2f",
            MODEL_NAME,
            elapsed_seconds,
        )

    except Exception as error:
        logger.exception(
            "Whisper model loading failed | model=%s | error_type=%s",
            MODEL_NAME,
            type(error).__name__,
        )
        raise TranscriptionError(
            "The local Whisper model could not be loaded."
        ) from error

    return _whisper_model


def transcribe_audio_file(file_path: Path) -> dict[str, Any]:
    """
    Transcribes an audio file locally into Greek text.

    Does not use an OpenAI API key and does not send the audio to OpenAI.
    """
    if not file_path.exists():
        logger.warning(
            "Audio file not found | extension=%s",
            file_path.suffix.lower() or "unknown",
        )
        raise TranscriptionError(
            f"Audio file not found: {file_path}"
        )

    if not file_path.is_file():
        logger.warning(
            "Invalid audio input | extension=%s",
            file_path.suffix.lower() or "unknown",
        )
        raise TranscriptionError(
            "The input is not a valid audio file."
        )

    model = get_transcription_model()
    started_at = time.perf_counter()

    logger.info(
        "Local transcription started | model=%s | extension=%s",
        MODEL_NAME,
        file_path.suffix.lower(),
    )

    try:
        result = model.transcribe(
            str(file_path),
            language="el",
            task="transcribe",
            fp16=False,
            verbose=False,
        )
    except Exception as error:
        logger.exception(
            "Local transcription failed | extension=%s | error_type=%s",
            file_path.suffix.lower(),
            type(error).__name__,
        )
        raise TranscriptionError(
            "Local transcription of the audio file failed. "
            "Check that FFmpeg is installed and that "
            "the file contains valid audio."
        ) from error

    transcript_text = str(result.get("text", "")).strip()

    if not transcript_text:
        logger.warning(
            "Empty transcript returned by Whisper | model=%s | extension=%s",
            MODEL_NAME,
            file_path.suffix.lower(),
        )
        raise TranscriptionError(
            "The model did not return any transcript text."
        )

    segments = []

    for segment in result.get("segments", []):
        segments.append(
            {
                "start": segment.get("start"),
                "end": segment.get("end"),
                "text": str(segment.get("text", "")).strip(),
            }
        )

    elapsed_seconds = time.perf_counter() - started_at

    logger.info(
        "Local transcription completed | model=%s | seconds=%.2f | "
        "segments=%s | transcript_characters=%s",
        MODEL_NAME,
        elapsed_seconds,
        len(segments),
        len(transcript_text),
    )

    return {
        "text": transcript_text,
        "chunks": segments,
        "model": f"openai-whisper/{MODEL_NAME}",
        "language": "el",
    }