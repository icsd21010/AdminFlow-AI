from pathlib import Path
from uuid import uuid4

from flask import Blueprint, current_app, render_template, request, send_from_directory, session

from config import allowed_file, safe_filename
from modules.check_housing_meals.service import generate_check_housing_meals
from utils import cleanup_files

bp = Blueprint("check_housing_meals", __name__)


@bp.route("/", methods=["GET", "POST"])
def check_housing_meals():
    if request.method == "GET":
        return render_template("check-housing-meals_form.html")

    provision_type = request.form.get("provision_type", "").strip()

    # Ανάκτηση της επιλεγμένης γλώσσας του χρήστη από το session
    session_lang = session.get("lang", "el")
    output_language = "English" if session_lang == "en" else "Ελληνικά"

    uploaded_file_paths = []
    uploaded_file_names = []
    skipped_file_names = []

    # Δημιουργία ή εύρεση του καταλόγου αποθήκευσης
    upload_folder = Path(current_app.config.get(
        "HOUSING_MEALS_UPLOAD_FOLDER", 
        current_app.config["UPLOAD_FOLDER"] + "/housing-meals"
    ))
    upload_folder.mkdir(parents=True, exist_ok=True)
    
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])
    output_folder.mkdir(parents=True, exist_ok=True)

    for uploaded_file in request.files.getlist("files"):
        if not uploaded_file or not uploaded_file.filename:
            continue

        original_filename = safe_filename(uploaded_file.filename)

        if not allowed_file(original_filename):
            skipped_file_names.append(original_filename)
            continue

        unique_filename = f"{uuid4().hex}_{original_filename}"
        file_path = upload_folder / unique_filename

        uploaded_file.save(file_path)
        uploaded_file_paths.append(str(file_path))
        uploaded_file_names.append(original_filename)

    if not uploaded_file_paths:
        return render_template(
            "check-housing-meals_form.html",
            error_message="You must upload at least one valid file (e.g., Application, ID, Tax form).",
            provision_type=provision_type,
            skipped_file_names=skipped_file_names,
        ), 400

    try:
        generated_report = generate_check_housing_meals(
            provision_type=provision_type,
            output_language=output_language,
            uploaded_file_paths=uploaded_file_paths,
        )
    except ValueError as error:
        return render_template(
            "check-housing-meals_form.html",
            error_message=str(error),
            provision_type=provision_type,
            skipped_file_names=skipped_file_names,
        ), 400
    except Exception as error:
        return render_template(
            "check-housing-meals_form.html",
            error_message=(
                "A problem occurred while verifying the applications. "
                f"Technical information: {error}"
            ),
            provision_type=provision_type,
            skipped_file_names=skipped_file_names,
        ), 500

    finally:
        # <--- ΠΡΟΣΘΗΚΗ: Καθαρίζει τα uploads αν υπήρξαν αρχεία
        if uploaded_file_paths:
            cleanup_files(uploaded_file_paths)

    output_filename = f"housing_meals_report_{uuid4().hex}.txt"
    output_path = output_folder / output_filename
    output_path.write_text(generated_report, encoding="utf-8")

    return render_template(
        "check-housing-meals_result.html",
        report=generated_report,
        output_filename=output_filename,
        provision_type=provision_type,
        uploaded_file_names=uploaded_file_names,
        skipped_file_names=skipped_file_names,
    )


@bp.route("/download/<output_filename>")
def download_report(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.startswith("housing_meals_report_") or not output_filename.endswith(".txt"):
        return "File not found.", 404

    if not (output_folder / output_filename).exists():
        return "File not found.", 404

    return send_from_directory(
        output_folder,
        output_filename,
        as_attachment=True,
        download_name="housing_meals_report.txt",
    )