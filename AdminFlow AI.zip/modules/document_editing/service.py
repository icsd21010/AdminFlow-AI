from pathlib import Path

from docx import Document
from openai import OpenAI
from pypdf import PdfReader

from config import OPENAI_API_KEY, OPENAI_MODEL


MODULE_DIR = Path(__file__).resolve().parent
EXAMPLES_DIR = MODULE_DIR / "examples"
REFERENCE_FILES_DIR = MODULE_DIR / "reference_files"

MAX_FILE_TEXT_LENGTH = 30000
MAX_REFERENCE_TEXT_LENGTH = 50000

SUPPORTED_TEXT_EXTENSIONS = {".txt", ".docx", ".pdf"}


def read_text_file(file_path: Path) -> str:
    try:
        return file_path.read_text(encoding="utf-8").strip()
    except UnicodeDecodeError:
        return file_path.read_text(encoding="utf-8-sig").strip()


def read_docx_file(file_path: Path) -> str:
    document = Document(file_path)

    paragraphs = [
        paragraph.text.strip()
        for paragraph in document.paragraphs
        if paragraph.text.strip()
    ]

    table_rows = []

    for table in document.tables:
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            table_rows.append(" | ".join(cells))

    return "\n".join(paragraphs + table_rows).strip()


def read_pdf_file(file_path: Path) -> str:
    reader = PdfReader(str(file_path))
    pages_text = []

    for page in reader.pages:
        page_text = page.extract_text() or ""
        pages_text.append(page_text.strip())

    return "\n".join(pages_text).strip()


def read_supported_file(file_path: Path) -> str:
    suffix = file_path.suffix.lower()

    if suffix == ".txt":
        return read_text_file(file_path)

    if suffix == ".docx":
        return read_docx_file(file_path)

    if suffix == ".pdf":
        return read_pdf_file(file_path)

    return ""


def limit_text(text: str, maximum_length: int) -> str:
    if len(text) <= maximum_length:
        return text

    return (
        text[:maximum_length]
        + "\n\n[The remaining file content was not sent due to the size limit.]"
    )


def read_module_file(filename: str) -> str:
    file_path = MODULE_DIR / filename

    if not file_path.exists():
        return ""

    return read_supported_file(file_path)


def read_reference_file(filename: str) -> str:
    file_path = REFERENCE_FILES_DIR / filename

    if not file_path.exists():
        return ""

    return read_supported_file(file_path)


def read_folder_reference_material(folder_path: Path) -> str:
    if not folder_path.exists():
        return ""

    sections = []

    for file_path in sorted(folder_path.rglob("*")):
        if not file_path.is_file():
            continue

        if file_path.suffix.lower() not in SUPPORTED_TEXT_EXTENSIONS:
            continue

        try:
            content = read_supported_file(file_path)
        except Exception as error:
            sections.append(
                f"\n--- FILE: {file_path.name} ---\n"
                f"[The file could not be read: {error}]"
            )
            continue

        if content:
            sections.append(
                f"\n--- REFERENCE FILE: {file_path.name} ---\n{content}"
            )

    return limit_text("\n".join(sections).strip(), MAX_REFERENCE_TEXT_LENGTH)


def read_uploaded_material(uploaded_file_paths: list[str]) -> str:
    sections = []

    for file_path_string in uploaded_file_paths:
        file_path = Path(file_path_string)

        if not file_path.exists():
            continue

        suffix = file_path.suffix.lower()

        if suffix not in SUPPORTED_TEXT_EXTENSIONS:
            continue

        try:
            content = read_supported_file(file_path)
        except Exception as error:
            sections.append(
                f"\n--- UPLOADED FILE: {file_path.name} ---\n"
                f"[The file could not be read: {error}]"
            )
            continue

        if content:
            sections.append(
                f"\n--- USER MATERIAL: {file_path.name} ---\n{content}"
            )

    return limit_text("\n".join(sections).strip(), MAX_FILE_TEXT_LENGTH)


def build_instructions() -> str:
    prompt = read_module_file("Instructions document editing.txt")
    output_template = read_reference_file("output_template.txt")
    style_guide = read_module_file("style_guide.txt")
    glossary = read_module_file("glossary.txt")
    examples = read_folder_reference_material(EXAMPLES_DIR)

    instructions_sections = [
        "APPLICATION: Language editing and text formatting",
        prompt,
    ]

    if glossary:
        instructions_sections.append(
            "\n## GLOSSARY\n"
            "Use this glossary to ensure accurate administrative terminology.\n"
            f"{glossary}"
        )

    if style_guide:
        instructions_sections.append(
            "\n## STYLE GUIDE\n"
            f"{style_guide}"
        )

    if output_template:
        instructions_sections.append(
            "\n## OUTPUT TEMPLATE\n"
            "Follow the output template below only as a structure.\n"
            f"{output_template}"
        )

    if examples:
        instructions_sections.append(
            "\n## OUTPUT EXAMPLES\n"
            "The examples show the desired tone, formatting, and quality level of editing.\n"
            f"{examples}"
        )

    return "\n\n".join(
        section for section in instructions_sections if section.strip()
    ).strip()


def build_user_input(
    language: str,
    tone: str,
    editing_level: str,
    formatting: str,
    show_changes: str,
    notes: str,
    uploaded_material: str,
) -> str:
    formatting_choice = "Yes" if formatting == "yes" else "No"
    show_changes_choice = "Yes" if show_changes == "yes" else "No"

    return f"""
## USER PARAMETERS


Language: {language}
Tone/Style: {tone}
Level of Editing: {editing_level}
Apply formatting: {formatting_choice}
Show changes/highlights: {show_changes_choice}


## ADDITIONAL USER INSTRUCTIONS


{notes if notes else "[No additional instructions were provided.]"}


## MATERIAL TO EDIT


{uploaded_material if uploaded_material else "[No readable text file was uploaded.]"}


## TASK


Edit and improve the provided text based on the requested level of editing, tone, and language.
Strictly adhere to the glossary and style guide. 
Do not alter the core meaning or factual content of the original document.
""".strip()


def generate_document_editing(
    language: str,
    tone: str,
    editing_level: str,
    formatting: str,
    show_changes: str,
    notes: str,
    uploaded_file_paths: list[str],
) -> str:
    if not OPENAI_API_KEY:
        raise ValueError("OPENAI_API_KEY is not set in the .env file.")
    if not OPENAI_API_KEY.startswith("sk-"):
        raise ValueError("OPENAI_API_KEY in the .env file does not look valid.")

    try:
        OPENAI_API_KEY.encode("ascii")
    except UnicodeEncodeError:
        raise ValueError(
            "OPENAI_API_KEY contains non-ASCII characters. "
            "Please retype it in the .env file without smart quotes or hidden characters."
        )

    instructions = build_instructions()
    uploaded_material = read_uploaded_material(uploaded_file_paths)

    user_input = build_user_input(
        language=language,
        tone=tone,
        editing_level=editing_level,
        formatting=formatting,
        show_changes=show_changes,
        notes=notes,
        uploaded_material=uploaded_material,
    )

    client = OpenAI(api_key=OPENAI_API_KEY)

    response = client.responses.create(
        model=OPENAI_MODEL,
        instructions=instructions,
        input=user_input,
    )

    return response.output_text.strip()