from pathlib import Path
from uuid import uuid4

from flask import Blueprint, current_app, render_template, request, send_from_directory

from config import allowed_file, safe_filename
from modules.document_editing.service import generate_document_editing
from utils import cleanup_files

bp = Blueprint("document_editing", __name__)


@bp.route("/", methods=["GET", "POST"])
def document_editing():
    if request.method == "GET":
        return render_template("document-editing_form.html")

    language = request.form.get("language", "").strip()
    tone = request.form.get("tone", "").strip()
    editing_level = request.form.get("editing_level", "").strip()
    formatting = request.form.get("formatting", "").strip()
    show_changes = request.form.get("show_changes", "").strip()
    notes = request.form.get("notes", "").strip()

    uploaded_file_paths = []
    uploaded_file_names = []
    skipped_file_names = []

    # Requires DOCUMENT_EDITING_UPLOAD_FOLDER to be set in config.py
    upload_folder = Path(current_app.config.get("DOCUMENT_EDITING_UPLOAD_FOLDER", current_app.config["UPLOAD_FOLDER"] + "/document-editing"))
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    for uploaded_file in request.files.getlist("files"):
        if not uploaded_file or not uploaded_file.filename:
            continue

        original_filename = safe_filename(uploaded_file.filename)

        if not allowed_file(original_filename):
            skipped_file_names.append(original_filename)
            continue

        unique_filename = f"{uuid4().hex}_{original_filename}"
        file_path = upload_folder / unique_filename

        uploaded_file.save(file_path)
        uploaded_file_paths.append(str(file_path))
        uploaded_file_names.append(original_filename)

    if not uploaded_file_paths:
        return render_template(
            "document-editing_form.html",
            error_message=(
                "You must upload at least one allowed text or document file "
                "(.txt, .pdf, .docx)."
            ),
            language=language,
            tone=tone,
            editing_level=editing_level,
            formatting=formatting,
            show_changes=show_changes,
            notes=notes,
            skipped_file_names=skipped_file_names,
        ), 400

    try:
        generated_document = generate_document_editing(
            language=language,
            tone=tone,
            editing_level=editing_level,
            formatting=formatting,
            show_changes=show_changes,
            notes=notes,
            uploaded_file_paths=uploaded_file_paths,
        )
    except ValueError as error:
        return render_template(
            "document-editing_form.html",
            error_message=str(error),
            language=language,
            tone=tone,
            editing_level=editing_level,
            formatting=formatting,
            show_changes=show_changes,
            notes=notes,
            skipped_file_names=skipped_file_names,
        ), 400
    except Exception as error:
        return render_template(
            "document-editing_form.html",
            error_message=(
                "A problem occurred while editing the document. "
                f"Technical information: {error}"
            ),
            language=language,
            tone=tone,
            editing_level=editing_level,
            formatting=formatting,
            show_changes=show_changes,
            notes=notes,
            skipped_file_names=skipped_file_names,
        ), 500

    finally:
        # <--- ΠΡΟΣΘΗΚΗ: Καθαρίζει τα uploads αν υπήρξαν αρχεία
        if uploaded_file_paths:
            cleanup_files(uploaded_file_paths)

    output_filename = f"edited_document_{uuid4().hex}.txt"
    output_path = output_folder / output_filename
    output_path.write_text(generated_document, encoding="utf-8")

    return render_template(
        "document-editing_result.html",
        edited_document=generated_document,
        output_filename=output_filename,
        language=language,
        tone=tone,
        editing_level=editing_level,
        formatting=formatting,
        show_changes=show_changes,
        notes=notes,
        uploaded_file_names=uploaded_file_names,
        skipped_file_names=skipped_file_names,
    )


@bp.route("/download/<output_filename>")
def download_edited_document(output_filename):
    output_folder = Path(current_app.config["OUTPUT_FOLDER"])

    if not output_filename.startswith("edited_document_") or not output_filename.endswith(".txt"):
        return "File not found.", 404

    if not (output_folder / output_filename).exists():
        return "File not found.", 404

    return send_from_directory(
        output_folder,
        output_filename,
        as_attachment=True,
        download_name="edited_document.txt",
    )