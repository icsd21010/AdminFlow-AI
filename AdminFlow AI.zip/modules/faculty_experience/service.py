from pathlib import Path
import pandas as pd

from docx import Document
from openai import OpenAI
from pypdf import PdfReader

from config import OPENAI_API_KEY, OPENAI_MODEL


MODULE_DIR = Path(__file__).resolve().parent
REFERENCE_FILES_DIR = MODULE_DIR / "reference_files"
EXAMPLES_DIR = MODULE_DIR / "examples"

MAX_FILE_TEXT_LENGTH = 50000
MAX_REFERENCE_TEXT_LENGTH = 50000

SUPPORTED_TEXT_EXTENSIONS = {".txt", ".docx", ".doc", ".pdf", ".xls", ".xlsx"}


def read_text_file(file_path: Path) -> str:
    try:
        return file_path.read_text(encoding="utf-8").strip()
    except UnicodeDecodeError:
        return file_path.read_text(encoding="utf-8-sig").strip()


def read_docx_file(file_path: Path) -> str:
    document = Document(file_path)

    paragraphs = [
        paragraph.text.strip()
        for paragraph in document.paragraphs
        if paragraph.text.strip()
    ]

    table_rows = []

    for table in document.tables:
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            table_rows.append(" | ".join(cells))

    return "\n".join(paragraphs + table_rows).strip()


def read_pdf_file(file_path: Path) -> str:
    reader = PdfReader(str(file_path))
    pages_text = []

    for page in reader.pages:
        page_text = page.extract_text() or ""
        pages_text.append(page_text.strip())

    return "\n".join(pages_text).strip()


def read_excel_file(file_path: Path) -> str:
    try:
        xls = pd.ExcelFile(file_path)
        sheets_text = []
        for sheet_name in xls.sheet_names:
            df = pd.read_excel(xls, sheet_name=sheet_name)
            sheets_text.append(f"--- Sheet: {sheet_name} ---\n{df.to_string(index=False)}")
        return "\n".join(sheets_text).strip()
    except Exception as e:
        return f"[Σφάλμα ανάγνωσης Excel: {e}]"


def read_supported_file(file_path: Path) -> str:
    suffix = file_path.suffix.lower()

    if suffix == ".txt":
        return read_text_file(file_path)

    if suffix == ".docx":
        return read_docx_file(file_path)

    if suffix == ".pdf":
        return read_pdf_file(file_path)
        
    if suffix in {".xls", ".xlsx"}:
        return read_excel_file(file_path)

    return ""


def limit_text(text: str, maximum_length: int) -> str:
    if len(text) <= maximum_length:
        return text

    return (
        text[:maximum_length]
        + "\n\n[The remaining file content was not sent due to the size limit.]"
    )


def read_module_file(filename: str) -> str:
    file_path = MODULE_DIR / filename

    if not file_path.exists():
        return ""

    return read_supported_file(file_path)


def read_reference_file(filename: str) -> str:
    file_path = REFERENCE_FILES_DIR / filename

    if not file_path.exists():
        return ""

    return read_supported_file(file_path)
    
    
def read_example_file(filename: str) -> str:
    file_path = EXAMPLES_DIR / filename

    if not file_path.exists():
        return ""

    return read_supported_file(file_path)


def read_uploaded_material(uploaded_file_paths: list[str]) -> str:
    sections = []

    for file_path_string in uploaded_file_paths:
        file_path = Path(file_path_string)

        if not file_path.exists():
            continue

        suffix = file_path.suffix.lower()

        if suffix not in SUPPORTED_TEXT_EXTENSIONS:
            continue

        try:
            content = read_supported_file(file_path)
        except Exception as error:
            sections.append(
                f"\n--- UPLOADED FILE: {file_path.name} ---\n"
                f"[Το αρχείο δεν μπόρεσε να διαβαστεί: {error}]"
            )
            continue

        if content:
            sections.append(
                f"\n--- ΥΛΙΚΟ ΧΡΗΣΤΗ (ΔΙΚΑΙΟΛΟΓΗΤΙΚΟ): {file_path.name} ---\n{content}"
            )

    return limit_text("\n".join(sections).strip(), MAX_FILE_TEXT_LENGTH)


def build_instructions() -> str:
    prompt = read_module_file("Instructions faculty_experience.txt")
    checklist = read_reference_file("checklist.txt")
    output_template = read_reference_file("output_template.txt")
    examples = read_example_file("output_examples.txt")

    instructions_sections = [
        "APPLICATION: Έλεγχος & Σύνταξη Διοικητικής Πράξης - Αναγνώριση Προϋπηρεσίας",
        prompt,
    ]

    if checklist:
        instructions_sections.append(
            "\n## ΚΑΝΟΝΕΣ ΚΑΙ ΠΡΟΫΠΟΘΕΣΕΙΣ ΕΛΕΓΧΟΥ (CHECKLIST)\n"
            f"{checklist}"
        )

    if output_template:
        instructions_sections.append(
            "\n## OUTPUT TEMPLATE (ΑΥΣΤΗΡΟ ΠΡΟΤΥΠΟ ΕΞΟΔΟΥ)\n"
            "Χρησιμοποίησε ΑΥΣΤΗΡΑ αυτή τη δομή για την απάντησή σου.\n"
            f"{output_template}"
        )

    if examples:
        instructions_sections.append(
            "\n## ΠΑΡΑΔΕΙΓΜΑΤΑ ΧΡΗΣΗΣ (FEW-SHOT EXAMPLES)\n"
            f"{examples}"
        )

    return "\n\n".join(
        section for section in instructions_sections if section.strip()
    ).strip()


def build_user_input(
    sector: str,
    uploaded_material: str,
) -> str:

    return f"""
## ΠΑΡΑΜΕΤΡΟΙ ΧΡΗΣΤΗ (USER PARAMETERS)

- Τύπος / Τομέας Φορέα Προϋπηρεσίας: {sector if sector else "[Δεν δηλώθηκε ρητά - Εξαγωγή από τα έγγραφα]"}


## ΥΛΙΚΟ ΠΡΟΣ ΑΝΑΛΥΣΗ (ΦΑΚΕΛΟΣ ΔΙΚΑΙΟΛΟΓΗΤΙΚΩΝ)

{uploaded_material if uploaded_material else "[Δεν ανέβηκε αναγνώσιμο αρχείο κειμένου.]"}


## ΕΡΓΑΣΙΑ (TASK)

Βάσει του υλικού προς ανάλυση και της επιλεγμένης παραμέτρου Φορέα ({sector}), διενέργησε τον έλεγχο πληρότητας και συνέταξε το Φύλλο Ελέγχου και τη Διοικητική Πράξη Αναγνώρισης Προϋπηρεσίας, ακολουθώντας αυστηρά το Output Template και το Checklist. 
Αν ο φορέας είναι ΑΕΙ/Ερευνητικό Κέντρο, εφάρμοσε το άρθρο 288 του Ν. 4957/2022. Αν είναι Δημόσιος Τομέας, εφάρμοσε το άρθρο 11 του Ν. 4354/2015. Μην επινοείς στοιχεία. Αν κάτι λείπει, χαρακτήρισε τον φάκελο ΕΛΛΙΠΗ.
""".strip()


def generate_faculty_experience_act(
    sector: str,
    uploaded_file_paths: list[str],
) -> str:
    if not OPENAI_API_KEY:
        raise ValueError("OPENAI_API_KEY is not set in the .env file.")
    if not OPENAI_API_KEY.startswith("sk-"):
        raise ValueError("OPENAI_API_KEY in the .env file does not look valid.")

    try:
        OPENAI_API_KEY.encode("ascii")
    except UnicodeEncodeError:
        raise ValueError(
            "OPENAI_API_KEY contains non-ASCII characters. "
            "Please retype it in the .env file without smart quotes or hidden characters."
        )

    instructions = build_instructions()
    uploaded_material = read_uploaded_material(uploaded_file_paths)

    user_input = build_user_input(
        sector=sector,
        uploaded_material=uploaded_material,
    )

    client = OpenAI(api_key=OPENAI_API_KEY)

    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=[
            {"role": "system", "content": instructions},
            {"role": "user", "content": user_input}
        ]
    )

    return response.choices[0].message.content.strip()